extends Area3D

var speed: float = 48.0
var damage: int = 25
varblood_scene := preload("res://BloodSplatter.tscn")

func _ready() -> void:
	if has_node("DespawnTimer"):
		$DespawnTimer.timeout.connect(queue_free)
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	global_position -= global_transform.basis.z * speed * delta

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		return
	if body.has_method("take_damage"):
		body.take_damage(damage)
		var sp = varblood_scene.instantiate()
		get_tree().current_scene.add_child(sp)
		sp.global_position = global_position
	queue_free()
