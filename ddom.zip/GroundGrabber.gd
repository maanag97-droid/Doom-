extends Area3D

var escape_requirement: int = 5
var current_progress: int = 0
var is_grabbing: bool = false
var player_ref: Node = null
var original_speed: float = 16.0
var original_jump: float = 12.0

@onready var arms_mesh: MeshInstance3D = get_node_or_null("Arms")

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _process(_delta: float) -> void:
	if is_grabbing and is_instance_valid(player_ref):
		if Input.is_key_pressed(KEY_SPACE) or Input.is_action_just_pressed("ui_accept"):
			escape_step()

func escape_step() -> void:
	if not is_grabbing or not is_instance_valid(player_ref):
		return
	current_progress += 1
	if player_ref.has_method("add_trauma"):
		player_ref.add_trauma(0.25)
	if player_ref.has_method("show_banner"):
		player_ref.show_banner("ESCAPING FLOOR TRAP: " + str(current_progress) + " / " + str(escape_requirement))
	if current_progress >= escape_requirement:
		release_player()

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player") and not is_grabbing:
		grab_player(body)

func grab_player(player: Node) -> void:
	player_ref = player
	is_grabbing = true
	current_progress = 0
	if arms_mesh:
		arms_mesh.visible = true
	original_speed = player.speed
	original_jump = player.jump_strength
	player.speed = 0.0
	player.jump_strength = 0.0
	player.active_grabber = self
	if player.has_method("show_banner"):
		player.show_banner("GRABBED BY FLOOR HANDS! Tap [JUMP] or [KICK] 5x to escape!")

func release_player() -> void:
	if is_instance_valid(player_ref):
		player_ref.speed = original_speed
		player_ref.jump_strength = original_jump
		player_ref.velocity.y = 11.0
		player_ref.active_grabber = null
		if player_ref.has_method("show_banner"):
			player_ref.show_banner("BROKE FREE FROM FLOOR TRAP!")
	queue_free()
