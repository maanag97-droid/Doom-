extends CPUParticles3D

func _ready() -> void:
	emitting = true
	await get_tree().create_timer(1.6).timeout
	queue_free()
