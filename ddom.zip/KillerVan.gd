extends CharacterBody3D

@export var speed: float = 8.5
@export var turn_speed: float = 2.2
@export var normal_gravity: float = 20.0
@export var float_gravity: float = 4.0
@export var push_force: float = 28.0

var player: Node3D = null
var is_flying: bool = false

func _ready() -> void:
	add_to_group("enemies")
	if has_node("MeshInstance3D"):
		$MeshInstance3D.mesh = Car8Mesh.build_mesh()
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]
	if has_node("KillZone"):
		var kz: Area3D = $KillZone
		if not kz.body_entered.is_connected(_on_KillArea_body_entered):
			kz.body_entered.connect(_on_KillArea_body_entered)

func _physics_process(delta: float) -> void:
	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]

	if is_flying:
		velocity.y -= float_gravity * delta
		velocity.x = lerpf(velocity.x, 0.0, 0.6 * delta)
		velocity.z = lerpf(velocity.z, 0.0, 0.6 * delta)
		rotate_x(1.5 * delta)
		rotate_z(1.2 * delta)
		if is_on_floor() and velocity.y < 0.0:
			recover_from_kick()
	else:
		if not is_on_floor():
			velocity.y -= normal_gravity * delta
		else:
			velocity.y = -0.1
		if is_instance_valid(player):
			var target_pos: Vector3 = player.global_position
			var car_pos: Vector3 = global_position
			var flat_target := Vector3(target_pos.x, car_pos.y, target_pos.z)
			if car_pos.distance_to(flat_target) > 0.5:
				var desired_transform: Transform3D = global_transform.looking_at(flat_target, Vector3.UP)
				var target_rotation_y: float = desired_transform.basis.get_euler().y
				rotation.y = lerp_angle(rotation.y, target_rotation_y, turn_speed * delta)
			rotation.x = lerpf(rotation.x, 0.0, 5.0 * delta)
			rotation.z = lerpf(rotation.z, 0.0, 5.0 * delta)
			var dist_to_player: float = car_pos.distance_to(target_pos)
			if dist_to_player > 3.2:
				var current_forward: Vector3 = -global_transform.basis.z
				var target_vel: Vector3 = current_forward * speed
				velocity.x = lerpf(velocity.x, target_vel.x, 4.0 * delta)
				velocity.z = lerpf(velocity.z, target_vel.z, 4.0 * delta)
			else:
				velocity.x = lerpf(velocity.x, 0.0, 5.0 * delta)
				velocity.z = lerpf(velocity.z, 0.0, 5.0 * delta)

	move_and_slide()

func take_damage(_amount: float) -> void:
	if is_flying:
		velocity.y += 10.0
		velocity.x += randf_range(-5.0, 5.0)
		velocity.z += randf_range(-5.0, 5.0)
		return
	is_flying = true
	velocity.y = 16.0
	if is_instance_valid(player):
		var dir_away: Vector3 = (global_position - player.global_position).normalized()
		velocity += dir_away * 22.0
		if player.has_method("show_banner"):
			player.show_banner("MIGHTY BOOT! YOU KICKED THE KILLER VAN!")

func recover_from_kick() -> void:
	await get_tree().create_timer(1.0).timeout
	if is_instance_valid(self):
		is_flying = false
		rotation.x = 0.0
		rotation.z = 0.0

func _on_KillArea_body_entered(body: Node) -> void:
	if body.is_in_group("Player") and not is_flying:
		if body.has_method("hit_by_car"):
			var knockback: Vector3 = (-global_transform.basis.z + Vector3(0, 0.35, 0)).normalized() * push_force
			body.hit_by_car(knockback)
