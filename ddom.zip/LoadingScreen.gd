extends Control

func _ready() -> void:
	await get_tree().create_timer(0.25).timeout
	if Global.next_scene_path != "":
		get_tree().change_scene_to_file(Global.next_scene_path)
	else:
		get_tree().change_scene_to_file("res://World.tscn")
