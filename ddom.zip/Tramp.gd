extends Area3D

@export var bounce_power: float = 24.0

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		body.velocity.y = bounce_power
		if body.has_method("show_banner"):
			body.show_banner("BOUNCE PAD! +24 UPWARD BOOST!")
