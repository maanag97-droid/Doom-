extends Control

var look_delta: Vector2 = Vector2.ZERO
var sensitivity: float = 0.24
var active_touch_index: int = -1

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and active_touch_index == -1:
			active_touch_index = event.index
		elif not event.pressed and event.index == active_touch_index:
			active_touch_index = -1
	elif event is InputEventScreenDrag:
		if active_touch_index == -1 or event.index == active_touch_index:
			look_delta += event.relative * sensitivity

func consume_look() -> Vector2:
	var out: Vector2 = look_delta
	look_delta = Vector2.ZERO
	return out
