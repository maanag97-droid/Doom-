extends Node3D

@export var is_dungeon_map: bool = false

func _ready() -> void:
	var brick_tex: Texture2D = load("res://BRICK_3D.PNG")
	var crate_tex: Texture2D = load("res://CRATE_2M.PNG")
	var wall_mat := StandardMaterial3D.new()
	wall_mat.albedo_texture = brick_tex
	wall_mat.uv1_scale = Vector3(2, 2, 2)
	wall_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST

	var crate_mat := StandardMaterial3D.new()
	crate_mat.albedo_texture = crate_tex
	crate_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST

	var cells: Array[Vector4i] = [Vector4i(4, 0, -12, 0), Vector4i(4, 0, -10, 0), Vector4i(2, 0, -9, 0), Vector4i(4, 0, -9, 0), Vector4i(7, 0, -9, 2), Vector4i(3, 1, -9, 0), Vector4i(4, 1, -9, 0), Vector4i(5, 0, -8, 0), Vector4i(5, 1, -8, 0), Vector4i(6, 1, -8, 0), Vector4i(7, 1, -8, 0), Vector4i(5, 0, -7, 0), Vector4i(6, 0, -7, 0), Vector4i(8, 1, -7, 0), Vector4i(7, 0, -6, 0), Vector4i(7, 0, -5, 0), Vector4i(9, 0, -3, 0)]
	if is_dungeon_map:
		cells = [Vector4i(0, 0, 0, 0), Vector4i(1, 0, 0, 0), Vector4i(0, 1, 0, 0), Vector4i(1, 1, 0, 0), Vector4i(0, 0, 1, 0), Vector4i(0, 1, 1, 0), Vector4i(1, 1, 1, 0), Vector4i(0, 0, -4, 0), Vector4i(-1, 0, -4, 0), Vector4i(1, 1, -4, 0), Vector4i(-3, 0, -2, 0), Vector4i(-2, 0, -2, 0), Vector4i(-2, 1, -2, 0)]

	var box_mesh := BoxMesh.new()
	box_mesh.size = Vector3(2.0, 3.0, 2.0)
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3(2.0, 3.0, 2.0)

	for c in cells:
		var sb := StaticBody3D.new()
		sb.position = Vector3(c.x * 2.0 + 1.0, c.y * 2.0 + 1.5, c.z * 2.0 + 1.0)
		var mi := MeshInstance3D.new()
		mi.mesh = box_mesh
		mi.material_override = crate_mat if c.w == 2 else wall_mat
		var cs := CollisionShape3D.new()
		cs.shape = box_shape
		sb.add_child(mi)
		sb.add_child(cs)
		add_child(sb)
