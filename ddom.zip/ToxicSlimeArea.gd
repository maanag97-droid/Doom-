extends Area3D

@export var damage_per_second: float = 12.0
var player_in_slime: Node = null

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)
	if not body_exited.is_connected(_on_body_exited):
		body_exited.connect(_on_body_exited)

func _process(delta: float) -> void:
	if is_instance_valid(player_in_slime) and player_in_slime.has_method("take_damage"):
		player_in_slime.take_damage(damage_per_second * delta)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		player_in_slime = body
		if body.has_method("show_banner"):
			body.show_banner("WARNING: TOXIC SLIME! Jump out!")

func _on_body_exited(body: Node) -> void:
	if body == player_in_slime:
		player_in_slime = null
