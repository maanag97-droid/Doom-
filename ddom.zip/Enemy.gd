extends CharacterBody3D

@export var max_health: int = 90
var current_health: int = 90
var move_speed: float = 5.2
var gravity: float = 30.0
var is_grabbed: bool = false
var player: Node3D = null
var attack_cooldown: float = 0.0
var blood_scene := preload("res://BloodSplatter.tscn")

func _ready() -> void:
	add_to_group("Enemy")
	add_to_group("enemies")
	current_health = max_health
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]
	if has_node("DamageArea"):
		var da: Area3D = $DamageArea
		if not da.body_entered.is_connected(_on_DamageArea_body_entered):
			da.body_entered.connect(_on_DamageArea_body_entered)

func _physics_process(delta: float) -> void:
	if is_grabbed:
		return
	if attack_cooldown > 0.0:
		attack_cooldown -= delta

	# Brutal Doom Thrown / Kicked flying physics
	if velocity.length() > 12.0:
		velocity.y -= gravity * delta
		velocity.x = lerpf(velocity.x, 0.0, 1.5 * delta)
		velocity.z = lerpf(velocity.z, 0.0, 1.5 * delta)
		move_and_slide()
		if is_on_wall():
			take_damage(55)
			velocity = Vector3.ZERO
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1

	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]

	if is_instance_valid(player):
		var p_pos: Vector3 = player.global_position
		var dist: float = global_position.distance_to(p_pos)
		var flat_target := Vector3(p_pos.x, global_position.y, p_pos.z)
		if global_position.distance_to(flat_target) > 0.2:
			look_at(flat_target, Vector3.UP)
		if dist > 2.2:
			var direction: Vector3 = (flat_target - global_position).normalized()
			velocity.x = direction.x * move_speed
			velocity.z = direction.z * move_speed
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			if attack_cooldown <= 0.0 and player.has_method("take_damage"):
				player.take_damage(10)
				attack_cooldown = 1.0
	else:
		velocity.x = 0.0
		velocity.z = 0.0

	move_and_slide()

func take_damage(amount: float) -> void:
	current_health -= int(amount)
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position + Vector3(0, 1.0, 0)
	if has_node("AnimatedSprite3D"):
		$AnimatedSprite3D.modulate = Color(1, 0.3, 0.3)
		get_tree().create_timer(0.12).timeout.connect(func():
			if is_instance_valid(self) and has_node("AnimatedSprite3D"):
				$AnimatedSprite3D.modulate = Color(1, 1, 1)
		)
	if current_health <= 0:
		Global.kills += 1
		queue_free()

func _on_AttackTimer_timeout() -> void:
	pass

func _on_DamageArea_body_entered(body: Node) -> void:
	if body.is_in_group("Player") and body.has_method("take_damage"):
		body.take_damage(10)
