extends OmniLight3D

func _process(_delta: float) -> void:
	if randf() < 0.05:
		light_energy = 0.2
	else:
		light_energy = 2.2
