extends ColorRect
