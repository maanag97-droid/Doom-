extends Node

@export var player_path: NodePath
@export var enemy_car_path: NodePath
@export var chase_distance: float = 25.0
