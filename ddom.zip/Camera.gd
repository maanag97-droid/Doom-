extends Camera3D
