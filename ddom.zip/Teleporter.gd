extends Area3D

@export var target_scene_path: String = "res://Level1.tscn"
@export var portal_label: String = "PORTAL"
var t: float = 0.0

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	t += delta * 2.5
	rotate_y(1.8 * delta)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player") and target_scene_path != "":
		Global.next_scene_path = target_scene_path
		get_tree().change_scene_to_file("res://LoadingScreen.tscn")
