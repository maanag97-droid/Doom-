extends Area3D

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		body.global_position = Vector3(0, 4, 0)
		body.velocity = Vector3.ZERO
