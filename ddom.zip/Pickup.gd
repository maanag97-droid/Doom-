extends StaticBody3D

@export var item_name: String = "Battery"
var base_y: float = 0.0
var t: float = 0.0

func _ready() -> void:
	base_y = position.y

func _physics_process(delta: float) -> void:
	t += delta * 2.5
	rotate_y(1.8 * delta)

func interact(player: Node) -> void:
	var inventory = player.get_node_or_null("Inventory")
	if inventory and inventory.has_method("add_item"):
		inventory.add_item(item_name)
		if player.has_method("show_banner"):
			player.show_banner("Picked up: " + item_name + " (Open BAG to combine!)")
		queue_free()
