extends Timer

var enemy_scene := preload("res://Enemy.tscn")
var player: Node3D = null
var max_enemies: int = 8

func _ready() -> void:
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]
	if not timeout.is_connected(_on_timeout):
		timeout.connect(_on_timeout)

func _on_timeout() -> void:
	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]
	var current_enemies: int = get_tree().get_nodes_in_group("Enemy").size()
	if current_enemies < max_enemies and is_instance_valid(player):
		var new_enemy = enemy_scene.instantiate()
		var angle: float = randf_range(0.0, TAU)
		var distance: float = randf_range(12.0, 20.0)
		var offset := Vector3(sin(angle), 0.0, cos(angle)) * distance
		var spawn_pos: Vector3 = player.global_position + offset
		spawn_pos.x = clampf(spawn_pos.x, -22.0, 26.0)
		spawn_pos.z = clampf(spawn_pos.z, -22.0, 22.0)
		spawn_pos.y = 2.0
		get_parent().add_child(new_enemy)
		new_enemy.global_position = spawn_pos
