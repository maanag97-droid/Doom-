extends Control

var item_data := {
	"Robot Head": {
		"name": "Robot Head",
		"description": "A cybernetic skull unit. Needs a power source.",
		"icon": preload("res://head.png")
	},
	"StaticBody": {
		"name": "Robot Head",
		"description": "A cybernetic skull unit. Needs a power source.",
		"icon": preload("res://head.png")
	},
	"Battery": {
		"name": "High-Voltage Battery",
		"description": "An industrial fusion cell. Tap another item to combine.",
		"icon": preload("res://CRATE_2M.PNG")
	},
	"Powered Robot": {
		"name": "Active Combat Drone",
		"description": "COMBINED! Grants +50 Max Health & +50 Ammo!",
		"icon": preload("res://head.png")
	},
	"Blue Key": {
		"name": "Blue Security Key",
		"description": "Unlocks the security blast door in the Main Hall.",
		"icon": preload("res://icon.png")
	}
}

var recipes := {
	"Robot Head + Battery": "Powered Robot",
	"Battery + Robot Head": "Powered Robot",
	"StaticBody + Battery": "Powered Robot",
	"Battery + StaticBody": "Powered Robot"
}

var items: Array[String] = []
var selected_index: int = -1

@onready var grid: GridContainer = $Panel/GridContainer
@onready var desc_label: Label = $Panel/DescriptionLabel
@onready var big_icon: TextureRect = $Panel/BigIcon
@onready var close_btn: Button = $Panel/CloseButton

func _ready() -> void:
	visible = false
	for saved_item in Global.inventory_items:
		items.append(saved_item)
	if close_btn and not close_btn.pressed.is_connected(toggle):
		close_btn.pressed.connect(toggle)
	desc_label.text = "Tap an item to inspect, or tap two items to combine them."

func toggle() -> void:
	visible = not visible
	if visible:
		if not DisplayServer.is_touchscreen_available():
			Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
		selected_index = -1
		refresh_display()
	else:
		if not DisplayServer.is_touchscreen_available():
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func add_item(item_name: String) -> void:
	items.append(item_name)
	Global.inventory_items = items.duplicate()
	if visible:
		refresh_display()

func refresh_display() -> void:
	for child in grid.get_children():
		child.queue_free()
	for i in range(items.size()):
		var item_name: String = items[i]
		var slot := Button.new()
		slot.custom_minimum_size = Vector2(110, 80)
		var display_title := item_name
		if item_data.has(item_name):
			display_title = item_data[item_name]["name"]
			slot.icon = item_data[item_name]["icon"]
		slot.text = display_title
		slot.expand_icon = true
		if i == selected_index:
			slot.modulate = Color(1.0, 0.35, 0.35)
		slot.pressed.connect(_on_slot_clicked.bind(i))
		grid.add_child(slot)

func _on_slot_clicked(index: int) -> void:
	if index < 0 or index >= items.size():
		return
	var clicked_item: String = items[index]
	if selected_index == -1:
		selected_index = index
		show_description(clicked_item)
		refresh_display()
		return
	if selected_index == index:
		selected_index = -1
		desc_label.text = "Selection cleared."
		refresh_display()
		return
	var first_item: String = items[selected_index]
	var key: String = first_item + " + " + clicked_item
	if recipes.has(key):
		var result_item: String = recipes[key]
		var hi: int = maxi(selected_index, index)
		var lo: int = mini(selected_index, index)
		items.remove_at(hi)
		items.remove_at(lo)
		items.append(result_item)
		Global.inventory_items = items.duplicate()
		selected_index = -1
		desc_label.text = "CRAFTED: " + result_item + "! (+50 HP & +50 Ammo)"
		var p = get_parent()
		if p and p.has_method("heal"):
			p.max_health += 50
			p.heal(50)
			p.add_ammo(50)
		refresh_display()
	else:
		selected_index = index
		show_description(clicked_item)
		desc_label.text += "\n(Cannot combine those items)"
		refresh_display()

func show_description(item_name: String) -> void:
	if item_data.has(item_name):
		var info = item_data[item_name]
		desc_label.text = info["name"] + ":\n" + info["description"]
		big_icon.texture = info["icon"]
	else:
		desc_label.text = item_name
