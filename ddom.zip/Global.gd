extends Node

var next_scene_path: String = ""
var kills: int = 0
var has_blue_key: bool = false
var inventory_items: Array[String] = []
var current_level_name: String = "Main Hall Arena"
