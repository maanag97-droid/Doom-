extends RigidBody3D

var damage: int = 85
var explosion_force: float = 28.0
var blood_scene := preload("res://BloodSplatter.tscn")
var explode_sound := preload("res://aud/sfx_exp_long4.wav")

func _ready() -> void:
	if has_node("Fuse"):
		if not $Fuse.timeout.is_connected(_on_Fuse_timeout):
			$Fuse.timeout.connect(_on_Fuse_timeout)
		$Fuse.wait_time = 2.2
		$Fuse.one_shot = true
		$Fuse.start()

func _on_Fuse_timeout() -> void:
	explode()

func explode() -> void:
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position

	var snd := AudioStreamPlayer3D.new()
	snd.stream = explode_sound
	snd.unit_db = 8.0
	get_tree().current_scene.add_child(snd)
	snd.global_position = global_position
	snd.play()
	snd.finished.connect(snd.queue_free)

	if has_node("BlastRadius"):
		var bodies = $BlastRadius.get_overlapping_bodies()
		for body in bodies:
			if body == self:
				continue
			if body.has_method("take_damage"):
				body.take_damage(damage)
			if body is CharacterBody3D and "velocity" in body:
				var dir: Vector3 = (body.global_position - global_position).normalized()
				body.velocity += (dir + Vector3(0, 0.5, 0)) * explosion_force
			elif body is RigidBody3D:
				var dir2: Vector3 = (body.global_position - global_position).normalized()
				body.apply_central_impulse((dir2 + Vector3(0, 0.5, 0)) * explosion_force)
	queue_free()
