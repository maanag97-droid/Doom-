extends RigidBody3D

func _ready() -> void:
	freeze = true
	if has_node("Area3D"):
		$Area3D.body_entered.connect(_on_Area_body_entered)

func _on_Area_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		await get_tree().create_timer(0.8).timeout
		if is_instance_valid(self):
			freeze = false
			sleeping = false
			apply_central_impulse(Vector3(0, -2, 0))
			await get_tree().create_timer(4.0).timeout
			if is_instance_valid(self):
				queue_free()
