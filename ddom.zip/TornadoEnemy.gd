extends CharacterBody3D

var speed: float = 3.6
var spin_speed: float = 10.0
var pull_force: float = 22.0

@onready var mesh: MeshInstance3D = get_node_or_null("MeshInstance3D")
@onready var suction_area: Area3D = get_node_or_null("Area3D")
var player: Node3D = null

func _ready() -> void:
	if suction_area:
		if not suction_area.body_entered.is_connected(_on_Area_body_entered):
			suction_area.body_entered.connect(_on_Area_body_entered)
		if not suction_area.body_exited.is_connected(_on_Area_body_exited):
			suction_area.body_exited.connect(_on_Area_body_exited)

func _physics_process(delta: float) -> void:
	if mesh:
		mesh.rotate_y(spin_speed * delta)
	if not is_on_floor():
		velocity.y -= 15.0 * delta
	else:
		velocity.y = 0.0

	if is_instance_valid(player):
		var direction: Vector3 = (player.global_position - global_position).normalized()
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		var dist: float = global_position.distance_to(player.global_position)
		if dist < 11.0 and player.has_method("push"):
			var pull_dir: Vector3 = (global_position - player.global_position).normalized()
			var side_dir: Vector3 = pull_dir.cross(Vector3.UP)
			var final_force: Vector3 = (pull_dir * 0.75) + (side_dir * 0.25)
			player.push(final_force * pull_force * delta)
	else:
		velocity.x = 0.0
		velocity.z = 0.0
	move_and_slide()

func _on_Area_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		player = body
		if body.has_method("show_banner"):
			body.show_banner("DUST TORNADO PULLING YOU IN!")

func _on_Area_body_exited(body: Node) -> void:
	if body == player:
		player = null
