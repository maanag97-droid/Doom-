extends ProgressBar

func _ready() -> void:
	max_value = 100
	value = 100
	await get_tree().process_frame
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		var player = players[0]
		player.health_changed.connect(_on_health_changed)
		value = player.current_health

func _on_health_changed(new_health: float) -> void:
	value = new_health
