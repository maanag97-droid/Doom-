extends Label

func _ready() -> void:
	await get_tree().process_frame
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		players[0].ammo_changed.connect(_on_ammo_changed)
		_on_ammo_changed(players[0].current_ammo)

func _on_ammo_changed(new_count: int) -> void:
	text = "AMMO: " + str(new_count)
	modulate = Color(1, 0.25, 0.25) if new_count <= 0 else Color(1, 0.92, 0.3)
