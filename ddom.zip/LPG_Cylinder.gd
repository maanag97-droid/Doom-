extends RigidBody3D

var health: int = 20
var blast_damage: int = 100
var blast_force: float = 40.0
var fuse_time: float = 2.2
var is_leaking: bool = false
var is_exploded: bool = false

@onready var gas_particles: CPUParticles3D = get_node_or_null("GasLeak")
@onready var blast_area: Area3D = get_node_or_null("BlastRadius")
@onready var audio: AudioStreamPlayer3D = get_node_or_null("BlastRadius/Audio")
@onready var mesh: MeshInstance3D = get_node_or_null("MeshInstance3D")
@onready var collider: CollisionShape3D = get_node_or_null("CollisionShape3D")

@export var explode_sound: AudioStream = preload("res://aud/sfx_exp_long4.wav")
var blood_scene := preload("res://BloodSplatter.tscn")

func _ready() -> void:
	add_to_group("Destructible")
	add_to_group("enemies")
	if gas_particles:
		gas_particles.emitting = false

func take_damage(amount: float) -> void:
	if is_exploded:
		return
	health -= int(amount)
	if health <= 15 and not is_leaking:
		start_leak()
	if health <= 0:
		explode()

func start_leak() -> void:
	is_leaking = true
	if gas_particles:
		gas_particles.emitting = true
	await get_tree().create_timer(fuse_time).timeout
	if not is_exploded:
		explode()

func explode() -> void:
	if is_exploded:
		return
	is_exploded = true
	if mesh:
		mesh.visible = false
	if collider:
		collider.disabled = true
	if gas_particles:
		gas_particles.emitting = false
	freeze = true

	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position

	if audio and explode_sound:
		audio.stream = explode_sound
		audio.unit_db = 10.0
		audio.play()

	if blast_area:
		for target in blast_area.get_overlapping_bodies():
			if target == self:
				continue
			if target.has_method("take_damage"):
				target.take_damage(blast_damage)
			if "velocity" in target:
				var dir: Vector3 = (target.global_position - global_position).normalized()
				target.velocity = (dir + Vector3.UP * 0.6) * blast_force

	await get_tree().create_timer(2.0).timeout
	queue_free()
