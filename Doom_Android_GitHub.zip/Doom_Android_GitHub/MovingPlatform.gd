extends Node3D

@export var travel_offset: Vector3 = Vector3(6.0, 0.0, 0.0)
@export var speed: float = 1.8
var start_pos: Vector3
var t: float = 0.0

func _ready() -> void:
	start_pos = position

func _physics_process(delta: float) -> void:
	t += delta * speed
	var factor: float = (sin(t) + 1.0) * 0.5
	var next_pos: Vector3 = start_pos.lerp(start_pos + travel_offset, factor)
	var move_delta: Vector3 = next_pos - position
	position = next_pos
	# Carry player if standing on top of this platform
	for p in get_tree().get_nodes_in_group("Player"):
		if is_instance_valid(p):
			var diff: Vector3 = p.global_position - global_position
			if absf(diff.x) < 2.4 and absf(diff.z) < 2.4 and diff.y > 0.0 and diff.y < 2.5:
				p.global_position += move_delta
