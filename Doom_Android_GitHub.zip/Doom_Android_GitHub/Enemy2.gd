extends CharacterBody3D

var speed: float = 4.2
var attack_range: float = 11.0
var damage: float = 6.0
var health: int = 35
var current_gravity: float = 0.0
var is_dead: bool = false
var is_pain: bool = false
var is_grabbed: bool = false
var shoot_timer: float = 0.0
var blood_scene := preload("res://BloodSplatter.tscn")

@onready var anim: AnimatedSprite3D = $AnimatedSprite3D
var player: Node3D = null

func _ready() -> void:
	add_to_group("Enemy")
	add_to_group("Enemy2")
	add_to_group("enemies")
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]

func _physics_process(delta: float) -> void:
	if is_grabbed:
		return
	if is_dead:
		apply_gravity(delta)
		return

	if velocity.length() > 12.0:
		velocity.y -= 30.0 * delta
		velocity.x = lerpf(velocity.x, 0.0, 1.5 * delta)
		velocity.z = lerpf(velocity.z, 0.0, 1.5 * delta)
		move_and_slide()
		if is_on_wall():
			take_damage(50)
			velocity = Vector3.ZERO
		return

	if is_pain:
		apply_gravity(delta)
		return

	velocity.x = 0.0
	velocity.z = 0.0
	if not is_on_floor():
		current_gravity -= 18.0 * delta
	else:
		current_gravity = -0.1

	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]

	if is_instance_valid(player):
		var p_pos: Vector3 = player.global_position
		var dist: float = global_position.distance_to(p_pos)
		var flat_target := Vector3(p_pos.x, global_position.y, p_pos.z)
		if global_position.distance_to(flat_target) > 0.2:
			look_at(flat_target, Vector3.UP)

		if dist > attack_range:
			var direction: Vector3 = (flat_target - global_position).normalized()
			velocity.x = direction.x * speed
			velocity.z = direction.z * speed
			if anim.animation != "Walk":
				anim.play("Walk")
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			handle_attack(delta)

	velocity.y = current_gravity
	move_and_slide()

func handle_attack(delta: float) -> void:
	if anim.animation != "attack":
		anim.play("attack")
	shoot_timer += delta
	if shoot_timer >= 1.0:
		shoot_timer = 0.0
		SoundManager.play_pistol()
		if is_instance_valid(player) and player.has_method("take_damage"):
			player.take_damage(damage)

func apply_gravity(delta: float) -> void:
	if not is_on_floor():
		current_gravity -= 18.0 * delta
	else:
		current_gravity = 0.0
	velocity = Vector3(0.0, current_gravity, 0.0)
	move_and_slide()

func take_damage(amount: float) -> void:
	if is_dead:
		return
	health -= int(amount)
	SoundManager.play_enemy_hit()
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position + Vector3(0, 1.0, 0)
	if health <= 0:
		die()
	else:
		is_pain = true
		anim.play("pain")
		await get_tree().create_timer(0.35).timeout
		if is_instance_valid(self) and not is_dead:
			is_pain = false
			anim.play("Walk")

func die() -> void:
	if is_dead:
		return
	is_dead = true
	SoundManager.play_enemy_die()
	Global.kills += 1
	anim.play("die")
	$CollisionShape3D.set_deferred("disabled", true)
	await get_tree().create_timer(4.0).timeout
	if is_instance_valid(self):
		queue_free()
