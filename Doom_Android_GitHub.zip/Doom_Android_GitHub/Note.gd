extends Area3D

@export_multiline var note_text: String = "SECRET LAB LOG #7734:\nThe passcode to the underground vault is 7734.\nBeware of the Killer Van and the Baron of Hell!"
var player_in_range: bool = false
var player_ref: Node = null

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)
	if not body_exited.is_connected(_on_body_exited):
		body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		player_in_range = true
		player_ref = body
		if body.has_method("show_banner"):
			body.show_banner("Note nearby! Tap [USE / E] to read.")

func _on_body_exited(body: Node) -> void:
	if body.is_in_group("Player"):
		player_in_range = false
		if player_ref and player_ref.has_method("hide_note"):
			player_ref.hide_note()
		player_ref = null

func interact(player: Node) -> void:
	SoundManager.play_pickup()
	if player.has_method("toggle_note"):
		player.toggle_note(note_text)
