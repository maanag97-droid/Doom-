extends Node

var sfx_shotgun: AudioStreamWAV
var sfx_explode: AudioStreamWAV
var sfx_pistol: AudioStreamWAV
var sfx_punch: AudioStreamWAV
var sfx_kick: AudioStreamWAV
var sfx_pickup: AudioStreamWAV
var sfx_enemy_hit: AudioStreamWAV
var sfx_enemy_die: AudioStreamWAV
var sfx_player_hurt: AudioStreamWAV
var sfx_door: AudioStreamWAV
var sfx_jump: AudioStreamWAV
var bgm_stream: AudioStreamWAV

var players_pool: Array[AudioStreamPlayer] = []
var bgm_player: AudioStreamPlayer

func _ready() -> void:
	for i in range(12):
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		players_pool.append(p)

	sfx_shotgun = _load_wav_or_synth("res://aud/sfx_weapon_shotgun1.wav", "shotgun")
	sfx_explode = _load_wav_or_synth("res://aud/sfx_exp_long4.wav", "explode")
	sfx_pistol = _synth_sfx("pistol")
	sfx_punch = _synth_sfx("punch")
	sfx_kick = _synth_sfx("kick")
	sfx_pickup = _synth_sfx("pickup")
	sfx_enemy_hit = _synth_sfx("enemy_hit")
	sfx_enemy_die = _synth_sfx("enemy_die")
	sfx_player_hurt = _synth_sfx("player_hurt")
	sfx_door = _synth_sfx("door")
	sfx_jump = _synth_sfx("jump")
	bgm_stream = _synth_bgm()

	bgm_player = AudioStreamPlayer.new()
	bgm_player.stream = bgm_stream
	bgm_player.volume_db = -9.0
	add_child(bgm_player)
	bgm_player.play()

func _load_wav_or_synth(path: String, fallback_kind: String) -> AudioStreamWAV:
	# 1. Try direct raw WAV bytes via FileAccess (works even without .import!)
	if FileAccess.file_exists(path):
		var raw: PackedByteArray = FileAccess.get_file_as_bytes(path)
		if raw.size() > 44:
			var wav := AudioStreamWAV.new()
			wav.format = AudioStreamWAV.FORMAT_16_BITS
			wav.mix_rate = 44100
			wav.stereo = false
			wav.data = raw.slice(44)
			return wav
	# 2. Try ResourceLoader
	if ResourceLoader.exists(path):
		var res = load(path)
		if res is AudioStreamWAV:
			return res
	# 3. Fallback procedural synthesis
	return _synth_sfx(fallback_kind)

func _synth_sfx(kind: String) -> AudioStreamWAV:
	var rate: int = 22050
	var dur: float = 0.28
	match kind:
		"shotgun": dur = 0.42
		"explode": dur = 0.85
		"pistol": dur = 0.22
		"punch": dur = 0.18
		"kick": dur = 0.28
		"pickup": dur = 0.24
		"enemy_hit": dur = 0.20
		"enemy_die": dur = 0.48
		"player_hurt": dur = 0.25
		"door": dur = 0.55
		"jump": dur = 0.22
	var samples: int = int(rate * dur)
	var buf := PackedByteArray()
	buf.resize(samples * 2)
	var phase: float = 0.0
	var seed_val: int = 1337
	for i in range(samples):
		var t: float = float(i) / float(rate)
		var prog: float = float(i) / float(samples)
		var env: float = pow(1.0 - prog, 1.4)
		seed_val = (seed_val * 1103515245 + 12345) & 0x7fffffff
		var noise: float = (float(seed_val % 20000) / 10000.0) - 1.0
		var sig: float = 0.0
		match kind:
			"shotgun":
				var freq: float = lerpf(160.0, 42.0, prog)
				phase += freq / float(rate)
				sig = (noise * 0.75 + sin(phase * TAU) * 0.65) * env
			"explode":
				var freq2: float = lerpf(110.0, 24.0, prog)
				phase += freq2 / float(rate)
				sig = (noise * 0.85 + sin(phase * TAU) * 0.6) * pow(1.0 - prog, 0.9)
			"pistol":
				var freq3: float = lerpf(320.0, 75.0, prog)
				phase += freq3 / float(rate)
				sig = (noise * 0.6 + sin(phase * TAU) * 0.7) * env
			"punch":
				var freq4: float = lerpf(190.0, 48.0, prog)
				phase += freq4 / float(rate)
				sig = (sin(phase * TAU) * 0.8 + noise * 0.45) * env
			"kick":
				var freq5: float = lerpf(150.0, 32.0, prog)
				phase += freq5 / float(rate)
				sig = (sin(phase * TAU) * 0.9 + noise * 0.5) * env
			"pickup":
				var freq6: float = 520.0 if prog < 0.45 else 780.0
				phase += freq6 / float(rate)
				sig = sin(phase * TAU) * 0.65 * env
			"enemy_hit":
				var freq7: float = lerpf(210.0, 95.0, prog)
				phase += freq7 / float(rate)
				sig = (sin(phase * TAU) * 0.6 + noise * 0.4) * env
			"enemy_die":
				var freq8: float = lerpf(240.0, 52.0, prog)
				phase += freq8 / float(rate)
				sig = (sin(phase * TAU) * 0.7 + noise * 0.5) * env
			"player_hurt":
				var freq9: float = lerpf(180.0, 80.0, prog)
				phase += freq9 / float(rate)
				sig = (sin(phase * TAU) * 0.7 + noise * 0.35) * env
			"door":
				var freq10: float = lerpf(90.0, 140.0, prog)
				phase += freq10 / float(rate)
				sig = (sin(phase * TAU) * 0.5 + noise * 0.25) * (1.0 - abs(prog - 0.5))
			"jump":
				var freq11: float = lerpf(160.0, 420.0, prog)
				phase += freq11 / float(rate)
				sig = sin(phase * TAU) * 0.6 * env
		var val: int = clampi(int(sig * 28000.0), -32767, 32767)
		buf.encode_s16(i * 2, val)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = buf
	return w

func _synth_bgm() -> AudioStreamWAV:
	var rate: int = 11025
	var notes: Array[float] = [82.41, 82.41, 164.81, 82.41, 82.41, 146.83, 82.41, 82.41, 130.81, 82.41, 82.41, 123.47, 82.41, 82.41, 130.81, 138.59]
	var step_dur: float = 0.18
	var total_samples: int = int(rate * step_dur * notes.size())
	var buf := PackedByteArray()
	buf.resize(total_samples * 2)
	var phase: float = 0.0
	for i in range(total_samples):
		var step_idx: int = mini(int(float(i) / (rate * step_dur)), notes.size() - 1)
		var local_t: float = fmod(float(i) / float(rate), step_dur) / step_dur
		var env: float = pow(1.0 - local_t, 0.7)
		var freq: float = notes[step_idx]
		phase += freq / float(rate)
		var saw: float = (fmod(phase, 1.0) * 2.0 - 1.0) * 0.45
		var sub: float = sin(phase * 0.5 * TAU) * 0.45
		var sig: float = (saw + sub) * env
		var val: int = clampi(int(sig * 16000.0), -32767, 32767)
		buf.encode_s16(i * 2, val)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = total_samples
	w.data = buf
	return w

func play_sfx(stream: AudioStreamWAV, vol_db: float = 2.0, pitch: float = 1.0) -> void:
	if stream == null:
		return
	for p in players_pool:
		if not p.playing:
			p.stream = stream
			p.volume_db = vol_db
			p.pitch_scale = pitch
			p.play()
			return
	players_pool[0].stream = stream
	players_pool[0].volume_db = vol_db
	players_pool[0].pitch_scale = pitch
	players_pool[0].play()

func play_shotgun() -> void: play_sfx(sfx_shotgun, 5.0, randf_range(0.95, 1.05))
func play_explode() -> void: play_sfx(sfx_explode, 6.0, randf_range(0.92, 1.05))
func play_pistol() -> void: play_sfx(sfx_pistol, 3.5, randf_range(0.95, 1.08))
func play_punch() -> void: play_sfx(sfx_punch, 4.0, randf_range(0.92, 1.08))
func play_kick() -> void: play_sfx(sfx_kick, 5.5, randf_range(0.92, 1.05))
func play_pickup() -> void: play_sfx(sfx_pickup, 3.0, 1.0)
func play_enemy_hit() -> void: play_sfx(sfx_enemy_hit, 2.5, randf_range(0.9, 1.1))
func play_enemy_die() -> void: play_sfx(sfx_enemy_die, 4.5, randf_range(0.88, 1.05))
func play_player_hurt() -> void: play_sfx(sfx_player_hurt, 4.0, 1.0)
func play_door() -> void: play_sfx(sfx_door, 4.0, 1.0)
func play_jump() -> void: play_sfx(sfx_jump, 2.0, 1.0)
