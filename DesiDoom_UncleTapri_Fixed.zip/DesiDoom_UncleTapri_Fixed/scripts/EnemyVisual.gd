extends Node3D

enum Anim { IDLE, WALK, ATTACK, HURT, DEATH }

@export var model_path: String = ""
@export var skin_path: String = ""
@export var model_scale: Vector3 = Vector3(1, 1, 1)

var _state: Anim = Anim.IDLE
var _t: float = 0.0
var _dead: bool = false
var _parts: Dictionary = {}

func _ready() -> void:
	scale = model_scale
	_boot_3d_skeleton()

func play(a: Anim) -> void:
	if _dead and a != Anim.DEATH:
		return
	if a == Anim.DEATH:
		_dead = true
	_state = a
	_t = 0.0

func _mat(c: Color, em: Color = Color.BLACK) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	if em != Color.BLACK:
		m.emission_enabled = true
		m.emission = em
		m.emission_energy_multiplier = 0.8
	return m

func _piv(p: Node3D, x: float, y: float, z: float) -> Node3D:
	var n := Node3D.new()
	n.position = Vector3(x, y, z)
	p.add_child(n)
	return n

func _box(p: Node3D, w: float, h: float, d: float, m: StandardMaterial3D, ox := 0.0, oy := 0.0, oz := 0.0) -> void:
	var o := Node3D.new()
	o.position = Vector3(ox, oy, oz)
	p.add_child(o)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(w, h, d)
	mi.mesh = bm
	mi.set_surface_override_material(0, m)
	o.add_child(mi)

func _sph(p: Node3D, r: float, m: StandardMaterial3D) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	mi.mesh = sm
	mi.set_surface_override_material(0, m)
	p.add_child(mi)

func _boot_3d_skeleton() -> void:
	var bone_col := Color(0.88, 0.85, 0.78)
	var armor_col := Color(0.55, 0.16, 0.12)
	var eye_col := Color(1.0, 0.25, 0.1)
	if "Mage" in model_path:
		armor_col = Color(0.22, 0.28, 0.82)
		eye_col = Color(0.3, 0.7, 1.0)
	elif "Rogue" in model_path:
		armor_col = Color(0.38, 0.15, 0.52)
		eye_col = Color(0.85, 0.2, 1.0)
	elif "Minion" in model_path:
		armor_col = Color(0.28, 0.45, 0.18)
		eye_col = Color(0.6, 1.0, 0.2)

	var sk := _mat(bone_col)
	var cl := _mat(armor_col)
	var ey := _mat(eye_col, eye_col)
	var steel := _mat(Color(0.72, 0.75, 0.8))

	var tor := _piv(self, 0, 0.95, 0)
	_parts["tor"] = tor
	_box(tor, 0.46, 0.44, 0.26, cl)
	_box(tor, 0.36, 0.22, 0.22, sk, 0, -0.32, 0)

	var hd := _piv(self, 0, 1.45, 0)
	_parts["hd"] = hd
	_sph(hd, 0.22, sk)
	_box(hd, 0.06, 0.05, 0.04, ey, -0.08, 0.04, 0.20)
	_box(hd, 0.06, 0.05, 0.04, ey, 0.08, 0.04, 0.20)

	for s in [-1, 1]:
		var k: String = "L" if s < 0 else "R"
		_parts[k + "sh"] = _piv(self, s * 0.32, 1.12, 0)
		_box(_parts[k + "sh"], 0.14, 0.38, 0.14, sk, 0, -0.19, 0)
		_parts[k + "el"] = _piv(self, s * 0.32, 0.70, 0)
		_box(_parts[k + "el"], 0.12, 0.34, 0.12, sk, 0, -0.17, 0)
		_parts[k + "lh"] = _piv(self, s * 0.14, 0.46, 0)
		_box(_parts[k + "lh"], 0.16, 0.32, 0.16, cl, 0, -0.15, 0)
		_parts[k + "kn"] = _piv(self, s * 0.14, 0.14, 0)
		_box(_parts[k + "kn"], 0.14, 0.28, 0.14, sk, 0, -0.13, 0)

	# Weapon in Right Hand & Shield in Left Hand
	if _parts.has("Rsh"):
		_box(_parts["Rsh"], 0.08, 0.75, 0.12, steel, 0, -0.45, 0.25)
	if "Warrior" in model_path and _parts.has("Lsh"):
		_box(_parts["Lsh"], 0.48, 0.65, 0.08, cl, -0.12, -0.25, 0.22)

func _lr(k: String, tx: float, sp: float, dt: float, tz := 0.0) -> void:
	if not _parts.has(k):
		return
	var n: Node3D = _parts[k]
	n.rotation.x = lerpf(n.rotation.x, deg_to_rad(tx), sp * dt)
	n.rotation.z = lerpf(n.rotation.z, deg_to_rad(tz), sp * dt)

func _process(delta: float) -> void:
	if not is_inside_tree():
		return
	_t += delta
	match _state:
		Anim.IDLE:
			var s := sin(_t * 2.0) * 8.0
			_lr("Lsh", s, 6, delta, -10)
			_lr("Rsh", -s, 6, delta, 10)
		Anim.WALK:
			var s := sin(_t * 8.5)
			_lr("Lsh", s * 42, 12, delta, -10)
			_lr("Rsh", -s * 42, 12, delta, 10)
			_lr("Llh", -s * 45, 12, delta)
			_lr("Rlh", s * 45, 12, delta)
		Anim.ATTACK:
			var s := sin(_t * 14.0)
			_lr("Rsh", -75 + s * 55, 16, delta, 10)
			_lr("Lsh", -35, 12, delta, -15)
		Anim.HURT:
			var s := sin(_t * 22.0) * 22.0
			_lr("Lsh", -35 + s, 20, delta, -12)
			_lr("Rsh", -35 - s, 20, delta, 12)
		Anim.DEATH:
			if _parts.has("tor"):
				_parts["tor"].rotation_degrees.x = minf(_parts["tor"].rotation_degrees.x + 85.0 * delta, 88.0)
			_lr("Lsh", 82, 5, delta, -30)
			_lr("Rsh", 82, 5, delta, 30)
