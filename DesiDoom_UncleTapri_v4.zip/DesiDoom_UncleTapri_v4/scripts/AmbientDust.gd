extends Node3D
## Spawns slowly drifting dust-mote particles to add atmosphere.
## Just place this node anywhere in the level.

@export var area_size   : Vector3 = Vector3(20.0, 5.0, 20.0)
@export var count       : int     = 35
@export var drift_speed : float   = 0.08

var _motes : Array = []

func _ready() -> void:
	_spawn_motes()

func _spawn_motes() -> void:
	for i in count:
		var mote := MeshInstance3D.new()
		var sm := SphereMesh.new()
		var sz := randf_range(0.03, 0.09)
		sm.radius = sz
		sm.height = sz * 2.0
		mote.mesh = sm

		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.85, 0.78, 0.68, 0.0)
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.emission_enabled = true
		mat.emission = Color(0.9, 0.82, 0.70)
		mat.emission_energy_multiplier = 0.35
		mat.unshaded = true
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		mote.set_surface_override_material(0, mat)

		var pos := Vector3(
			randf_range(-area_size.x * 0.5, area_size.x * 0.5),
			randf_range(0.3, area_size.y),
			randf_range(-area_size.z * 0.5, area_size.z * 0.5)
		)
		mote.position = pos
		add_child(mote)

		_motes.append({
			"node": mote,
			"mat":  mat,
			"t":    randf() * TAU,
			"speed": randf_range(0.4, 1.2),
			"drift_x": randf_range(-1.0, 1.0),
			"drift_z": randf_range(-1.0, 1.0),
			"base_y":  pos.y,
			"amp_y":   randf_range(0.08, 0.25),
			"alpha":   randf_range(0.08, 0.32)
		})

func _process(delta: float) -> void:
	for d in _motes:
		if not is_instance_valid(d["node"]): continue
		d["t"] += delta * d["speed"]
		var node : MeshInstance3D = d["node"]

		# Gentle float
		node.position.y = d["base_y"] + sin(d["t"] * 0.7) * d["amp_y"]
		node.position.x += d["drift_x"] * drift_speed * delta
		node.position.z += d["drift_z"] * drift_speed * delta

		# Slowly fade in/out
		var alpha : float = float(d["alpha"]) * (0.6 + sin(float(d["t"]) * 0.9) * 0.4)
		d["mat"].albedo_color.a = alpha

		# Wrap around area bounds
		var half := area_size * 0.5
		if abs(node.position.x) > half.x:
			node.position.x = -node.position.x * 0.9
		if abs(node.position.z) > half.z:
			node.position.z = -node.position.z * 0.9
