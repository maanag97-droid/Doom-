extends Node3D
## Visual character node for the player.
## Loads Kenney characterMedium.fbx + idle/run/jump animations + humanMaleA skin.
## Falls back to procedural box-man if assets fail to load.

enum Anim { IDLE, WALK, JUMP, HURT, DEATH }

const MODEL  := "res://assets/characters/kenney/characterMedium.fbx"
const SKIN   := "res://assets/characters/kenney/skins/humanMaleA.png"
const A_IDLE := "res://assets/characters/kenney/animations/idle.fbx"
const A_RUN  := "res://assets/characters/kenney/animations/run.fbx"
const A_JUMP := "res://assets/characters/kenney/animations/jump.fbx"

var _state  : Anim = Anim.IDLE
var _t      : float = 0.0
var _dead   : bool  = false
var _ap     : AnimationPlayer = null
var _cur    : String = ""
var _ok     : bool  = false
var _parts  : Dictionary = {}

func _ready() -> void:
	_ok = _boot_fbx()
	if not _ok:
		push_warning("PlayerCharacter: FBX load failed - using procedural box-man")
		_boot_procedural()

# -- FBX loader ----------------------------------------------------------------
func _boot_fbx() -> bool:
	if not ResourceLoader.exists(MODEL):
		push_warning("PlayerCharacter: model missing: " + MODEL)
		return false
	var ps := load(MODEL) as PackedScene
	if not ps: return false
	var body := ps.instantiate() as Node3D
	add_child(body)

	if ResourceLoader.exists(SKIN):
		_skin(body, load(SKIN) as Texture2D)
	else:
		push_warning("PlayerCharacter: skin missing: " + SKIN)

	var skel := _find(body, "Skeleton3D") as Skeleton3D
	if not skel:
		push_warning("PlayerCharacter: no Skeleton3D found in model")
		body.queue_free()
		return false

	_ap = AnimationPlayer.new()
	body.add_child(_ap)
	_ap.root_node = _ap.get_path_to(skel)

	var lib := AnimationLibrary.new()
	_load_fbx_anim(lib, A_IDLE, "idle")
	_load_fbx_anim(lib, A_RUN,  "run")
	_load_fbx_anim(lib, A_JUMP, "jump")

	if lib.get_animation_list().is_empty():
		push_warning("PlayerCharacter: no animations loaded")
		body.queue_free()
		return false

	_ap.add_animation_library("", lib)
	var first := str(lib.get_animation_list()[0])
	_ap.play(first)
	_cur = first
	return true

## Load one FBX animation clip - tries multiple known name patterns
func _load_fbx_anim(lib: AnimationLibrary, fbx_path: String, key: String) -> void:
	if not ResourceLoader.exists(fbx_path):
		push_warning("PlayerCharacter: anim missing: " + fbx_path)
		return
	var ps := load(fbx_path) as PackedScene
	if not ps: return
	var tmp := ps.instantiate()
	var src := _find(tmp, "AnimationPlayer") as AnimationPlayer
	if src:
		var name := _pick_anim(src, key)
		if name != "":
			var clip := src.get_animation(name).duplicate(true) as Animation
			_retarget(clip)
			lib.add_animation(key, clip)
		else:
			push_warning("PlayerCharacter: no usable anim in " + fbx_path
				+ " | found: " + ", ".join(src.get_animation_list()))
	tmp.free()

## Pick the best matching animation name from a list of candidates
func _pick_anim(ap: AnimationPlayer, hint: String) -> String:
	var lists := {
		"idle": ["Root|Idle","Idle","idle","Armature|Idle","Root|idle","Take 001","mixamo.com"],
		"run":  ["Root|Run","Run","run","Armature|Run","Root|run","Root|Walk","Walk","walk"],
		"jump": ["Root|Jump","Jump","jump","Armature|Jump","Root|jump","Root|Fall","Fall","fall"]
	}
	for c in lists.get(hint, []):
		if ap.has_animation(c): return c
	var all := ap.get_animation_list()
	return str(all[0]) if all.size() > 0 else ""

## Retarget FBX animation tracks to drive our skeleton directly.
## FBX tracks look like "SomePath/Skeleton3D:BoneName" ? we want ".:BoneName"
func _retarget(anim: Animation) -> void:
	for i in anim.get_track_count():
		var p := str(anim.track_get_path(i))
		if ":" in p:
			anim.track_set_path(i, NodePath(".:" + p.split(":")[1]))

# -- Public API ----------------------------------------------------------------
func play(a: Anim) -> void:
	if _dead and a != Anim.DEATH: return
	if a == Anim.DEATH: _dead = true
	if _state == a and a != Anim.HURT: return
	_state = a; _t = 0.0
	if _ok:
		match a:
			Anim.IDLE:  _clip("idle",  true)
			Anim.WALK:  _clip("run",   true)
			Anim.JUMP:  _clip("jump",  false)
			Anim.HURT:  _clip("idle",  true)   # no hurt clip - hold idle
			Anim.DEATH: _clip("idle",  false)

func _clip(name: String, looping: bool) -> void:
	if not _ap or not is_inside_tree(): return
	var same := (_cur == name)
	var still_playing := _ap.is_playing()
	if same and (looping or still_playing): return
	if _ap.has_animation(name):
		var anim := _ap.get_animation(name)
		if anim:
			anim.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
		_ap.play(name)
		_cur = name

# -- Helpers -------------------------------------------------------------------
func _find(node: Node, cls: String) -> Node:
	if node.get_class() == cls: return node
	for c in node.get_children():
		var r := _find(c, cls)
		if r: return r
	return null

func _skin(node: Node, tex: Texture2D) -> void:
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		for i in mi.get_surface_override_material_count():
			var m := mi.get_active_material(i)
			if m is BaseMaterial3D:
				var m2 := m.duplicate() as StandardMaterial3D
				if m2: m2.albedo_texture = tex; mi.set_surface_override_material(i, m2)
	for c in node.get_children(): _skin(c, tex)

# -- Procedural box-man fallback -----------------------------------------------
func _mat(c: Color, em: Color = Color.BLACK) -> StandardMaterial3D:
	var m := StandardMaterial3D.new(); m.albedo_color = c
	if em != Color.BLACK:
		m.emission_enabled = true; m.emission = em; m.emission_energy_multiplier = 0.6
	return m
func _piv(p: Node3D, x: float, y: float, z: float) -> Node3D:
	var n := Node3D.new(); n.position = Vector3(x,y,z); p.add_child(n); return n
func _box(p: Node3D, w: float, h: float, d: float, m: StandardMaterial3D,
		  ox:=0.0, oy:=0.0, oz:=0.0) -> void:
	var o := Node3D.new(); o.position = Vector3(ox,oy,oz); p.add_child(o)
	var mi := MeshInstance3D.new(); var bm := BoxMesh.new()
	bm.size = Vector3(w,h,d); mi.mesh = bm
	mi.set_surface_override_material(0, m); o.add_child(mi)
func _sph(p: Node3D, r: float, m: StandardMaterial3D) -> void:
	var mi := MeshInstance3D.new(); var sm := SphereMesh.new()
	sm.radius = r; sm.height = r*2; mi.mesh = sm
	mi.set_surface_override_material(0, m); p.add_child(mi)
func _boot_procedural() -> void:
	var sk := _mat(Color(.95,.75,.55)); var cl := _mat(Color(.2,.35,.7))
	var bt := _mat(Color(.25,.15,.08)); var hr := _mat(Color(.15,.08,.03))
	var ey := _mat(Color(.1,.1,.85))
	var hd := _piv(self,0,1.55,0); _parts["hd"]=hd
	_sph(hd,.19,sk); _box(hd,.38,.11,.38,hr,0,.11,0)
	_box(hd,.055,.04,.025,ey,-.07,.03,.17); _box(hd,.055,.04,.025,ey,.07,.03,.17)
	var tor := _piv(self,0,1.0,0); _parts["tor"]=tor
	_box(tor,.42,.46,.24,cl); _box(tor,.38,.22,.22,cl,0,-.34,0)
	for s in [-1,1]:
		var k : String = "L" if s<0 else "R"
		_parts[k+"sh"] = _piv(self,s*.28,1.17,0); _box(_parts[k+"sh"],.14,.32,.14,cl,0,-.16,0)
		_parts[k+"el"] = _piv(self,s*.28,.83,0);  _box(_parts[k+"el"],.12,.28,.12,sk,0,-.14,0)
		_parts[k+"hp"] = _piv(self,s*.13,.55,0);  _box(_parts[k+"hp"],.16,.36,.16,cl,0,-.18,0)
		_parts[k+"kn"] = _piv(self,s*.13,.17,0);  _box(_parts[k+"kn"],.14,.32,.14,bt,0,-.16,0)
func _lr(k:String, tx:float, sp:float, dt:float, tz:=0.0) -> void:
	if not _parts.has(k): return
	var n: Node3D = _parts[k]
	n.rotation.x = lerp(n.rotation.x, deg_to_rad(tx), sp*dt)
	n.rotation.z = lerp(n.rotation.z, deg_to_rad(tz), sp*dt)
func _process(delta: float) -> void:
	if not is_inside_tree(): return
	if _ok: return
	_t += delta
	match _state:
		Anim.IDLE:
			var s := sin(_t*1.8)*8.0
			_lr("Lsh",s,8,delta,-5); _lr("Rsh",-s,8,delta,5)
			_lr("Lhp",0,8,delta); _lr("Rhp",0,8,delta)
			_lr("Lkn",0,8,delta); _lr("Rkn",0,8,delta)
			if _parts.has("tor"): _parts["tor"].position.y = 1.0+sin(_t*1.2)*.013
		Anim.WALK:
			var s := sin(_t*7.0)
			_lr("Lsh",s*35,10,delta,-5); _lr("Rsh",-s*35,10,delta,5)
			_lr("Lhp",-s*40,10,delta);   _lr("Rhp",s*40,10,delta)
			_lr("Lkn",max(0,s)*35,10,delta); _lr("Rkn",max(0,-s)*35,10,delta)
			if _parts.has("tor"): _parts["tor"].position.y = 1.0+abs(sin(_t*7.0))*.035
		Anim.JUMP:
			_lr("Lsh",-60,12,delta,-10); _lr("Rsh",-60,12,delta,10)
			_lr("Lhp",-20,12,delta);     _lr("Rhp",-20,12,delta)
		Anim.HURT:
			var s := sin(_t*22)*16
			_lr("Lsh",-20+s,20,delta); _lr("Rsh",-20-s,20,delta)
		Anim.DEATH:
			if _parts.has("tor"):
				_parts["tor"].rotation_degrees.x = min(_parts["tor"].rotation_degrees.x+65*delta,86)
			_lr("Lsh",90,3,delta,-20); _lr("Rsh",90,3,delta,20)
