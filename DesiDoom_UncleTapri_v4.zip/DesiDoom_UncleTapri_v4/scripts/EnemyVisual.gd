extends Node3D
## EnemyVisual - drop-in visual component for any skeleton enemy.
## Accepts a model path so each enemy type can use its own GLB skin.
## Falls back through Kenney zombie ? procedural goblin if assets missing.
##
## Usage (from enemy script _ready):
##   var vis := load("res://scripts/EnemyVisual.gd").new()
##   vis.model_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Rogue.glb"
##   vis.skin_path  = "res://assets/characters/kaykit/skeletons/models/Skeleton_Rogue_skeleton_texture.png"
##   vis.model_scale = Vector3(0.88, 0.88, 0.88)
##   add_child(vis)

enum Anim { IDLE, WALK, ATTACK, HURT, DEATH }

@export var model_path  : String = "res://assets/characters/kaykit/skeletons/models/Skeleton_Warrior.glb"
@export var skin_path   : String = "res://assets/characters/kaykit/skeletons/texture/skeleton_texture.png"
@export var model_scale : Vector3 = Vector3(0.92, 0.92, 0.92)

const A_MOVEMENT := "res://assets/characters/kaykit/animations/Rig_Medium_MovementBasic.glb"
const A_COMBAT   := "res://assets/characters/kaykit/animations/Rig_Medium_CombatMelee.glb"
const A_GENERAL  := "res://assets/characters/kaykit/animations/Rig_Medium_General.glb"

const N_IDLE   := "Idle_A"
const N_RUN    := "Running_A"
const N_ATTACK := "Melee_1H_Attack_Chop"
const N_HURT   := "Hit_A"
const N_DEATH  := "Death_A"

var _state : Anim = Anim.IDLE
var _t     : float = 0.0
var _dead  : bool  = false
var _ap    : AnimationPlayer = null
var _cur   : String = ""
var _ok    : bool   = false
var _parts : Dictionary = {}

func _ready() -> void:
	_ok = _boot_glb()
	if not _ok: _ok = _boot_kenney_zombie()
	if not _ok: _boot_goblin()

# -- GLB loader ----------------------------------------------------------------
func _boot_glb() -> bool:
	if not ResourceLoader.exists(model_path): return false
	var ps := load(model_path) as PackedScene
	if not ps: return false
	var body := ps.instantiate() as Node3D
	body.scale = model_scale
	add_child(body)
	if ResourceLoader.exists(skin_path):
		_skin(body, load(skin_path) as Texture2D)
	var skel := _find(body, "Skeleton3D") as Skeleton3D
	if not skel: body.queue_free(); return false
	_ap = AnimationPlayer.new()
	skel.get_parent().add_child(_ap)
	_ap.root_node = _ap.get_path_to(skel)
	var lib := AnimationLibrary.new()
	_load_anim(lib, A_GENERAL,  N_IDLE,   "idle")
	_load_anim(lib, A_MOVEMENT, N_RUN,    "run")
	_load_anim(lib, A_COMBAT,   N_ATTACK, "attack")
	_load_anim(lib, A_GENERAL,  N_HURT,   "hurt")
	_load_anim(lib, A_GENERAL,  N_DEATH,  "death")
	if lib.get_animation_list().is_empty(): body.queue_free(); return false
	_ap.add_animation_library("", lib)
	var start : String = "idle" if lib.get_animation_list().has("idle") else str(lib.get_animation_list()[0])
	_ap.play(start); _cur = start
	return true

func _load_anim(lib: AnimationLibrary, glb: String, anim_name: String, key: String) -> void:
	if not ResourceLoader.exists(glb): return
	var ps := load(glb) as PackedScene
	if not ps: return
	var tmp := ps.instantiate()
	var src := _find_ap(tmp)
	if src and src.has_animation(anim_name):
		var clip := src.get_animation(anim_name).duplicate(true) as Animation
		for i in clip.get_track_count():
			var p : String = str(clip.track_get_path(i))
			if ":" in p: clip.track_set_path(i, NodePath(".:" + p.split(":")[1]))
		lib.add_animation(key, clip)
	tmp.free()

# -- Kenney zombie fallback ----------------------------------------------------
const KN_MODEL := "res://assets/characters/kenney/characterMedium.fbx"
const KN_SKIN  := "res://assets/characters/kenney/skins/zombieMaleA.png"
const KN_IDLE  := "res://assets/characters/kenney/animations/idle.fbx"
const KN_RUN   := "res://assets/characters/kenney/animations/run.fbx"

func _boot_kenney_zombie() -> bool:
	if not ResourceLoader.exists(KN_MODEL): return false
	var ps := load(KN_MODEL) as PackedScene
	if not ps: return false
	var body := ps.instantiate() as Node3D
	body.scale = Vector3(0.88, 0.88, 0.88)
	add_child(body)
	if ResourceLoader.exists(KN_SKIN): _skin(body, load(KN_SKIN) as Texture2D)
	var skel := _find(body, "Skeleton3D") as Skeleton3D
	if not skel: body.queue_free(); return false
	_ap = AnimationPlayer.new(); body.add_child(_ap)
	_ap.root_node = _ap.get_path_to(skel)
	var lib := AnimationLibrary.new()
	_load_fbx_anim(lib, KN_IDLE, "idle"); _load_fbx_anim(lib, KN_RUN, "run")
	if lib.get_animation_list().is_empty(): body.queue_free(); return false
	_ap.add_animation_library("", lib); _ap.play("idle"); _cur = "idle"
	return true

func _load_fbx_anim(lib: AnimationLibrary, fbx_path: String, key: String) -> void:
	if not ResourceLoader.exists(fbx_path): return
	var ps := load(fbx_path) as PackedScene
	if not ps: return
	var tmp := ps.instantiate()
	var src := _find(tmp, "AnimationPlayer") as AnimationPlayer
	if src:
		var cands := {"idle": ["Root|Idle","Idle","idle"], "run": ["Root|Run","Run","run","Root|Walk","Walk"]}
		var found := ""
		for c in cands.get(key, []):
			if src.has_animation(c): found = c; break
		if found == "" and src.get_animation_list().size() > 0:
			found = src.get_animation_list()[0]
		if found != "":
			var clip := src.get_animation(found).duplicate(true) as Animation
			for i in clip.get_track_count():
				var p := str(clip.track_get_path(i))
				if ":" in p: clip.track_set_path(i, NodePath(".:" + p.split(":")[1]))
			lib.add_animation(key, clip)
	tmp.free()

# -- Public API ----------------------------------------------------------------
func play(a: Anim) -> void:
	if _dead and a != Anim.DEATH: return
	if a == Anim.DEATH: _dead = true
	if _state == a and a != Anim.HURT: return
	_state = a; _t = 0.0
	if _ok:
		match a:
			Anim.IDLE:   _clip("idle",   true)
			Anim.WALK:   _clip("run",    true)
			Anim.ATTACK: _clip("attack", false)
			Anim.HURT:   _clip("hurt",   false)
			Anim.DEATH:  _clip("death",  false)

func _clip(name: String, looping: bool) -> void:
	if not _ap or not is_inside_tree(): return
	var same := (_cur == name)
	if same and (looping or _ap.is_playing()): return
	if _ap.has_animation(name):
		var anim := _ap.get_animation(name)
		if anim: anim.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
		_ap.play(name); _cur = name

# -- Helpers -------------------------------------------------------------------
func _find(node: Node, cls: String) -> Node:
	if node.get_class() == cls: return node
	for c in node.get_children():
		var r := _find(c, cls)
		if r: return r
	return null

func _find_ap(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer: return node as AnimationPlayer
	for c in node.get_children():
		var r := _find_ap(c)
		if r: return r
	return null

func _skin(node: Node, tex: Texture2D) -> void:
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		for i in mi.get_surface_override_material_count():
			var m = mi.get_active_material(i)
			if m is BaseMaterial3D:
				var m2 := m.duplicate() as StandardMaterial3D
				if m2: m2.albedo_texture = tex; mi.set_surface_override_material(i, m2)
	for c in node.get_children(): _skin(c, tex)

# -- Procedural goblin fallback ------------------------------------------------
func _mat(c:Color, em:Color=Color.BLACK)->StandardMaterial3D:
	var m:=StandardMaterial3D.new(); m.albedo_color=c
	if em!=Color.BLACK: m.emission_enabled=true; m.emission=em; m.emission_energy_multiplier=0.7
	return m
func _piv(p:Node3D,x:float,y:float,z:float)->Node3D:
	var n:=Node3D.new(); n.position=Vector3(x,y,z); p.add_child(n); return n
func _box(p:Node3D,w:float,h:float,d:float,m:StandardMaterial3D,ox:=0.0,oy:=0.0,oz:=0.0)->void:
	var o:=Node3D.new(); o.position=Vector3(ox,oy,oz); p.add_child(o)
	var mi:=MeshInstance3D.new(); var bm:=BoxMesh.new()
	bm.size=Vector3(w,h,d); mi.mesh=bm; mi.set_surface_override_material(0,m); o.add_child(mi)
func _sph(p:Node3D,r:float,m:StandardMaterial3D)->void:
	var mi:=MeshInstance3D.new(); var sm:=SphereMesh.new()
	sm.radius=r; sm.height=r*2; mi.mesh=sm; mi.set_surface_override_material(0,m); p.add_child(mi)
func _boot_goblin()->void:
	scale=Vector3(.84,.84,.84)
	var sk:=_mat(Color(.22,.50,.16)); var cl:=_mat(Color(.28,.17,.07))
	var ey:=_mat(Color(.95,.85,.0),Color(1.0,.6,0)); var fn:=_mat(Color(.94,.92,.84))
	var tor:=_piv(self,0,.95,0); _parts["tor"]=tor
	_box(tor,.50,.42,.28,cl); _box(tor,.42,.24,.24,cl,0,-.34,0)
	var hd:=_piv(self,0,1.42,0); _parts["hd"]=hd
	_sph(hd,.22,sk); _box(hd,.06,.05,.03,ey,-.08,.04,.20); _box(hd,.06,.05,.03,ey,.08,.04,.20)
	_box(hd,.04,.08,.03,fn,-.06,-.12,.20); _box(hd,.04,.08,.03,fn,.06,-.12,.20)
	for s in [-1,1]:
		var k : String = "L" if s<0 else "R"
		_parts[k+"sh"]=_piv(self,s*.32,1.10,0); _box(_parts[k+"sh"],.16,.38,.16,sk,0,-.19,0)
		_parts[k+"el"]=_piv(self,s*.32,.68,0);  _box(_parts[k+"el"],.14,.34,.14,sk,0,-.17,0)
		_parts[k+"lh"]=_piv(self,s*.14,.44,0);  _box(_parts[k+"lh"],.18,.30,.18,cl,0,-.15,0)
		_parts[k+"kn"]=_piv(self,s*.14,.12,0);  _box(_parts[k+"kn"],.16,.26,.16,sk,0,-.13,0)
func _lr(k:String,tx:float,sp:float,dt:float,tz:=0.0)->void:
	if not _parts.has(k): return
	var n:Node3D=_parts[k]
	n.rotation.x=lerp(n.rotation.x,deg_to_rad(tx),sp*dt)
	n.rotation.z=lerp(n.rotation.z,deg_to_rad(tz),sp*dt)
func _process(delta:float)->void:
	if not is_inside_tree() or _ok: return
	_t+=delta
	match _state:
		Anim.IDLE:
			var s:=sin(_t*1.4)*7; _lr("Lsh",s,6,delta,-12); _lr("Rsh",-s,6,delta,12)
			if _parts.has("tor"): _parts["tor"].position.y=.95+sin(_t*1.4)*.016
		Anim.WALK,Anim.ATTACK:
			var s:=sin(_t*8.0)
			_lr("Lsh",s*42,12,delta,-12); _lr("Rsh",-s*42,12,delta,12)
			_lr("Llh",-s*45,12,delta); _lr("Rlh",s*45,12,delta)
			_lr("Lkn",max(0,s)*42,12,delta); _lr("Rkn",max(0,-s)*42,12,delta)
		Anim.HURT:
			var s:=sin(_t*20)*20; _lr("Lsh",-32+s,20,delta,-12); _lr("Rsh",-32-s,20,delta,12)
		Anim.DEATH:
			if _parts.has("tor"): _parts["tor"].rotation_degrees.x=min(_parts["tor"].rotation_degrees.x+72*delta,88)
			_lr("Lsh",82,4,delta,-30); _lr("Rsh",82,4,delta,30)
