extends StaticBody3D

signal pulled(is_on: bool)
var _is_on: bool = false
var _handle: Node3D
var _hint: Label3D

func _ready() -> void:
	add_to_group("Interactable")
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.2, 1.5, 1.2)
	col.shape = bs
	col.position = Vector3(0, 0.75, 0)
	add_child(col)

	var base := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.5, 0.2, 0.4)
	base.mesh = bm
	base.position = Vector3(0, 0.1, 0)
	add_child(base)

	_handle = Node3D.new()
	_handle.position = Vector3(0, 0.2, 0)
	add_child(_handle)
	var shaft := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.05
	cm.bottom_radius = 0.05
	cm.height = 0.8
	shaft.mesh = cm
	shaft.position = Vector3(0, 0.4, 0)
	_handle.add_child(shaft)
	_handle.rotation_degrees.x = -32.0

	_hint = Label3D.new()
	_hint.text = "VAULT LEVER #7734\n[USE / E]"
	_hint.font_size = 40
	_hint.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_hint.modulate = Color(0.4, 0.95, 1.0)
	_hint.position = Vector3(0, 1.6, 0)
	add_child(_hint)

func interact(player: Node) -> void:
	_is_on = not _is_on
	SoundManager.play_door()
	_handle.rotation_degrees.x = 32.0 if _is_on else -32.0
	pulled.emit(_is_on)
	for d in get_tree().get_nodes_in_group("Interactable"):
		if d.name == "Door":
			d.is_open = true
	if player.has_method("show_banner"):
		player.show_banner("VAULT LEVER PULLED! SECRET DOOR & BONUS AMMO UNLOCKED!")
	if player.has_method("add_ammo"):
		player.add_ammo(30)
