extends StaticBody3D

@export var npc_name: String = "Raju Chaiwala"
@export var npc_role: String = "shop" # "shop" or "guide"
@export_multiline var dialogue_text: String = "Welcome to Raju Tapri! Spend your Gold Coins on Cutting Chai Overdrive, Flying Chappal, or VIP Pressure Horn!"
@export var shirt_color: Color = Color(0.9, 0.35, 0.1)

var _parts: Dictionary = {}
var _t: float = 0.0
var _label: Label3D

func _ready() -> void:
	add_to_group("Interactable")
	_build_body()
	_label = Label3D.new()
	_label.text = npc_name + "\n[Tap USE / E]"
	_label.font_size = 44
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.modulate = Color(1.0, 0.92, 0.3)
	_label.position = Vector3(0, 2.35, 0)
	_label.outline_size = 10
	add_child(_label)

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	return m

func _piv(p: Node3D, x: float, y: float, z: float) -> Node3D:
	var n := Node3D.new()
	n.position = Vector3(x, y, z)
	p.add_child(n)
	return n

func _box(p: Node3D, w: float, h: float, d: float, m: StandardMaterial3D, ox := 0.0, oy := 0.0, oz := 0.0) -> void:
	var o := Node3D.new()
	o.position = Vector3(ox, oy, oz)
	p.add_child(o)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(w, h, d)
	mi.mesh = bm
	mi.set_surface_override_material(0, m)
	o.add_child(mi)

func _build_body() -> void:
	var root := Node3D.new()
	root.scale = Vector3(1.15, 1.15, 1.15)
	add_child(root)
	var sk := _mat(Color(0.85, 0.62, 0.42))
	var cl := _mat(shirt_color)
	var pn := _mat(Color(0.18, 0.22, 0.32))
	var hr := _mat(Color(0.1, 0.08, 0.06))
	var hd := _piv(root, 0, 1.55, 0)
	_parts["hd"] = hd
	_box(hd, 0.36, 0.36, 0.36, sk)
	_box(hd, 0.40, 0.14, 0.40, hr, 0, 0.16, 0)
	var tor := _piv(root, 0, 1.0, 0)
	_parts["tor"] = tor
	_box(tor, 0.46, 0.50, 0.26, cl)
	for s in [-1, 1]:
		var k: String = "L" if s < 0 else "R"
		_parts[k + "arm"] = _piv(root, s * 0.32, 1.20, 0)
		_box(_parts[k + "arm"], 0.15, 0.55, 0.15, sk, 0, -0.22, 0)
		_parts[k + "leg"] = _piv(root, s * 0.14, 0.55, 0)
		_box(_parts[k + "leg"], 0.17, 0.55, 0.17, pn, 0, -0.27, 0)

func _process(delta: float) -> void:
	_t += delta
	if _parts.has("Rarm"):
		_parts["Rarm"].rotation_degrees.z = 145.0 + sin(_t * 5.0) * 22.0
	if _parts.has("hd"):
		_parts["hd"].rotation_degrees.y = sin(_t * 1.8) * 18.0

func interact(player: Node) -> void:
	SoundManager.play_pickup()
	if npc_role == "shop" and player.has_method("toggle_chai_shop"):
		player.toggle_chai_shop()
	elif player.has_method("toggle_note"):
		player.toggle_note(npc_name + ":\n" + dialogue_text)
