extends StaticBody3D

@export var gem_reward: int = 35
@export var health_reward: int = 25
var _open: bool = false
var _open_t: float = 0.0
var _lid: MeshInstance3D
var _lid_base_y: float = 1.15
var _hint: Label3D

func _ready() -> void:
	add_to_group("Interactable")
	_build_visual()

func _build_visual() -> void:
	var col := CollisionShape3D.new()
	var cbox := BoxShape3D.new()
	cbox.size = Vector3(1.8, 1.4, 1.2)
	col.shape = cbox
	col.position = Vector3(0, 0.7, 0)
	add_child(col)

	var body_mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(1.8, 0.9, 1.2)
	body_mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = load("res://assets/textures/texture_wood_floor.png")
	mat.albedo_color = Color(0.75, 0.5, 0.2)
	body_mesh.position = Vector3(0, 0.45, 0)
	body_mesh.set_surface_override_material(0, mat)
	add_child(body_mesh)

	_lid = MeshInstance3D.new()
	var lid_box := BoxMesh.new()
	lid_box.size = Vector3(1.85, 0.45, 1.25)
	_lid.mesh = lid_box
	var gmat := StandardMaterial3D.new()
	gmat.albedo_color = Color(0.95, 0.75, 0.15)
	gmat.emission_enabled = true
	gmat.emission = Color(0.9, 0.6, 0.1)
	gmat.emission_energy_multiplier = 0.5
	_lid.set_surface_override_material(0, gmat)
	_lid.position = Vector3(0, _lid_base_y, 0)
	add_child(_lid)

	_hint = Label3D.new()
	_hint.text = "GOLDEN CHEST\n[USE / E]"
	_hint.font_size = 42
	_hint.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_hint.modulate = Color(1.0, 0.9, 0.25)
	_hint.position = Vector3(0, 2.1, 0)
	add_child(_hint)

func interact(player: Node) -> void:
	if _open:
		return
	_open = true
	SoundManager.play_door()
	SoundManager.play_gem()
	_hint.text = "PAISA HI PAISA! +" + str(gem_reward) + " COINS!"
	if player.has_method("collect_gem"):
		player.collect_gem(gem_reward)
	if health_reward > 0 and player.has_method("heal"):
		player.heal(health_reward)
	if player.has_method("show_banner"):
		player.show_banner("TREASURE CHEST OPENED! PAISA HI PAISA HOGA! (+" + str(gem_reward) + " Coins)")

func _process(delta: float) -> void:
	if _open and _open_t < 1.0:
		_open_t = minf(_open_t + delta * 3.0, 1.0)
		_lid.position.y = _lid_base_y + _open_t * 0.6
		_lid.rotation.x = -_open_t * 0.9
