extends Control

var radius: float = 75.0
var ongoing_drag: int = -1
var knob_offset: Vector2 = Vector2.ZERO

func _process(delta: float) -> void:
	if ongoing_drag == -1 and knob_offset.length() > 0.1:
		knob_offset = knob_offset.lerp(Vector2.ZERO, 16.0 * delta)
		queue_redraw()

func _draw() -> void:
	var center: Vector2 = size * 0.5
	draw_circle(center, radius, Color(0.08, 0.08, 0.1, 0.55))
	draw_arc(center, radius, 0.0, TAU, 40, Color(1.0, 0.35, 0.15, 0.85), 3.5)
	draw_arc(center, radius * 0.45, 0.0, TAU, 28, Color(1.0, 1.0, 1.0, 0.2), 1.5)
	var knob_pos: Vector2 = center + knob_offset
	draw_circle(knob_pos, 32.0, Color(0.95, 0.25, 0.1, 0.85))
	draw_arc(knob_pos, 32.0, 0.0, TAU, 28, Color(1.0, 0.85, 0.4, 0.95), 3.0)

func _input(event: InputEvent) -> void:
	var center_global: Vector2 = global_position + size * 0.5
	if event is InputEventScreenTouch:
		if event.pressed:
			if ongoing_drag == -1 and event.position.distance_to(center_global) <= radius * 1.45:
				ongoing_drag = event.index
				_update_knob(event.position - center_global)
		else:
			if event.index == ongoing_drag:
				ongoing_drag = -1
				queue_redraw()
	elif event is InputEventScreenDrag:
		if event.index == ongoing_drag:
			_update_knob(event.position - center_global)

func _update_knob(offset: Vector2) -> void:
	if offset.length() > radius:
		knob_offset = offset.normalized() * radius
	else:
		knob_offset = offset
	queue_redraw()

func get_value() -> Vector2:
	if knob_offset.length() > 10.0:
		return knob_offset / radius
	return Vector2.ZERO
