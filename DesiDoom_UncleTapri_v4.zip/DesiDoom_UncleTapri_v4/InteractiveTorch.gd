extends Node3D

@export var lit: bool = true
var _t: float = 0.0
var _light: OmniLight3D

func _ready() -> void:
	var post := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.08
	cm.bottom_radius = 0.06
	cm.height = 0.8
	post.mesh = cm
	var pmat := StandardMaterial3D.new()
	pmat.albedo_color = Color(0.35, 0.22, 0.12)
	post.set_surface_override_material(0, pmat)
	add_child(post)

	var flame := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.16
	sm.height = 0.36
	flame.mesh = sm
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.65, 0.15)
	flame.set_surface_override_material(0, fmat)
	flame.position = Vector3(0, 0.5, 0)
	add_child(flame)

	_light = OmniLight3D.new()
	_light.light_color = Color(1.0, 0.6, 0.2)
	_light.light_energy = 3.2
	_light.omni_range = 10.0
	_light.position = Vector3(0, 0.6, 0)
	add_child(_light)

func _process(delta: float) -> void:
	_t += delta * 8.0
	if _light and lit:
		_light.light_energy = 3.2 + sin(_t * 2.3) * 0.5 + sin(_t * 5.7) * 0.25
