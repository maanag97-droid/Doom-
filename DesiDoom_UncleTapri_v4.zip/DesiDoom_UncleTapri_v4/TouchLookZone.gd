extends Control

var look_delta: Vector2 = Vector2.ZERO
var sensitivity: float = 0.25
var active_touch_index: int = -1

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if active_touch_index == -1 and get_global_rect().has_point(event.position):
				var p = get_parent()
				if p:
					for btn_name in ["BtnFire", "BtnKick", "BtnGrenade", "BtnJump", "BtnUse", "BtnChaiShop", "BtnLight", "BtnBag", "BtnMap"]:
						var b: Control = p.get_node_or_null(btn_name)
						if b and b.visible and b.get_global_rect().has_point(event.position):
							return
				active_touch_index = event.index
		else:
			if event.index == active_touch_index:
				active_touch_index = -1
	elif event is InputEventScreenDrag:
		if event.index == active_touch_index:
			look_delta += event.relative * sensitivity

func consume_look() -> Vector2:
	var out: Vector2 = look_delta
	look_delta = Vector2.ZERO
	return out
