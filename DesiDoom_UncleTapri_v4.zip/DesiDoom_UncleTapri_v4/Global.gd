extends Node

var next_scene_path: String = ""
var kills: int = 0
var coins: int = 25
var xp: int = 0
var player_level: int = 1
var combo_count: int = 0
var combo_timer: float = 0.0
var has_blue_key: bool = false
var chappal_boomerang_unlocked: bool = true
var vip_horn_unlocked: bool = false
var inventory_items: Array[String] = []
var current_level_name: String = "Main Hall Arena"

var meme_lines: Array[String] = [
	"PATT SE HEADSHOT!",
	"HEAVY DRIVER! SIDE PLEASE!",
	"KHATAM! TATA! BYE BYE!",
	"BAWANDAR AA GAYA!",
	"PAISA HI PAISA HOGA!",
	"JALWA HAI HAMARA!",
	"MUMMY KI FLYING CHAPPAL!",
	"GARAM CHAI KI PYALI HO!",
	"25 DIN MEIN PAISA DOUBLE!"
]

func add_xp(amount: int) -> void:
	xp += amount
	var needed: int = player_level * 100
	if xp >= needed:
		xp -= needed
		player_level += 1
		for p in get_tree().get_nodes_in_group("Player"):
			if is_instance_valid(p) and p.has_method("on_level_up"):
				p.on_level_up(player_level)

func register_kill() -> String:
	kills += 1
	combo_count += 1
	combo_timer = 4.5
	add_xp(35)
	var line: String = meme_lines[kills % meme_lines.size()]
	if combo_count > 1:
		return str(combo_count) + "x COMBO! " + line
	return line

func _process(delta: float) -> void:
	if combo_timer > 0.0:
		combo_timer -= delta
		if combo_timer <= 0.0:
			combo_count = 0
