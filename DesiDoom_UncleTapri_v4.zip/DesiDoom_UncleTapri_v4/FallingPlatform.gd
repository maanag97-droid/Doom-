extends RigidBody3D

var start_transform: Transform3D

func _ready() -> void:
	freeze = true
	start_transform = global_transform
	if has_node("Area3D"):
		$Area3D.body_entered.connect(_on_Area_body_entered)

func _on_Area_body_entered(body: Node) -> void:
	if body.is_in_group("Player") and freeze:
		if body.has_method("show_banner"):
			body.show_banner("FALLING PLATFORM SHAKING! Jump quickly!")
		await get_tree().create_timer(0.75).timeout
		if is_instance_valid(self):
			freeze = false
			sleeping = false
			apply_central_impulse(Vector3(0, -3, 0))
			await get_tree().create_timer(3.5).timeout
			if is_instance_valid(self):
				freeze = true
				linear_velocity = Vector3.ZERO
				angular_velocity = Vector3.ZERO
				global_transform = start_transform
