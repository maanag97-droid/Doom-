extends Node3D

@export var damage: int = 15
var _t: float = 0.0
var _up: bool = false
var _spikes_root: Node3D
var _area: Area3D

func _ready() -> void:
	var base := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(2.2, 0.1, 2.2)
	base.mesh = bm
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = Color(0.32, 0.28, 0.28)
	base.set_surface_override_material(0, bmat)
	add_child(base)

	_spikes_root = Node3D.new()
	add_child(_spikes_root)
	var smat := StandardMaterial3D.new()
	smat.albedo_color = Color(0.75, 0.75, 0.8)
	for r in [-0.6, 0.0, 0.6]:
		for c in [-0.6, 0.0, 0.6]:
			var mi := MeshInstance3D.new()
			var cyl := CylinderMesh.new()
			cyl.top_radius = 0.02
			cyl.bottom_radius = 0.12
			cyl.height = 0.8
			mi.mesh = cyl
			mi.set_surface_override_material(0, smat)
			mi.position = Vector3(c, 0.4, r)
			_spikes_root.add_child(mi)

	_area = Area3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(2.0, 1.0, 2.0)
	cs.shape = bs
	cs.position = Vector3(0, 0.5, 0)
	_area.add_child(cs)
	add_child(_area)
	_area.body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	_t += delta
	var cycle: float = fmod(_t, 3.0)
	_up = (cycle > 1.8)
	var target_y: float = 0.0 if _up else -0.75
	_spikes_root.position.y = move_toward(_spikes_root.position.y, target_y, 5.0 * delta)

func _on_body_entered(body: Node) -> void:
	if _up and body.has_method("take_damage"):
		body.take_damage(damage)
