extends Area3D

@export var value: int = 5
@export var magnet_range: float = 6.5

var _collected: bool = false
var _t: float = 0.0
var _base_y: float = 0.0

func _ready() -> void:
	_base_y = global_position.y
	_t = randf() * TAU
	body_entered.connect(_on_body)

	var mesh := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.25
	cyl.bottom_radius = 0.25
	cyl.height = 0.08
	mesh.mesh = cyl
	mesh.rotation_degrees.x = 90.0
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.85, 0.1)
	mat.emission_enabled = true
	mat.emission = Color(0.95, 0.65, 0.05)
	mat.emission_energy_multiplier = 0.9
	mesh.set_surface_override_material(0, mat)
	add_child(mesh)

	var col := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = 0.6
	col.shape = sp
	add_child(col)

func _on_body(body: Node3D) -> void:
	if _collected:
		return
	if body.is_in_group("Player") and body.has_method("collect_gem"):
		_collect(body)

func _collect(body: Node3D) -> void:
	if _collected:
		return
	_collected = true
	SoundManager.play_gem()
	body.collect_gem(value)
	queue_free()

func _process(delta: float) -> void:
	if _collected:
		return
	_t += delta
	rotation.y += 3.2 * delta
	for p in get_tree().get_nodes_in_group("Player"):
		if is_instance_valid(p):
			var dist: float = global_position.distance_to(p.global_position)
			if dist < magnet_range:
				var dir: Vector3 = (p.global_position + Vector3(0, 1.0, 0) - global_position).normalized()
				global_position += dir * 16.0 * delta
				if dist < 1.1:
					_collect(p)
				return
	global_position.y = _base_y + sin(_t * 3.0) * 0.14
