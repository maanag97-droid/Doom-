extends StaticBody3D

@export var title: String = "ANCIENT DESI RUNE #7734"
@export_multiline var lore_text: String = "Legend says only a true Heavy Driver with a Flying Chappal and Cutting Chai can defeat the Skeleton Warlord and the Omni Van!"

func _ready() -> void:
	add_to_group("Interactable")
	var col := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.4, 1.8, 0.4)
	col.shape = bs
	col.position = Vector3(0, 0.9, 0)
	add_child(col)

	var slab := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.3, 1.7, 0.2)
	slab.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = load("res://assets/textures/texture_rune_wall.png")
	mat.emission_enabled = true
	mat.emission = Color(0.15, 0.45, 0.95)
	mat.emission_energy_multiplier = 0.5
	slab.position = Vector3(0, 0.85, 0)
	slab.set_surface_override_material(0, mat)
	add_child(slab)

	var lbl := Label3D.new()
	lbl.text = title + "\n[USE / E]"
	lbl.font_size = 38
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(0.5, 0.9, 1.0)
	lbl.position = Vector3(0, 2.0, 0)
	add_child(lbl)

func interact(player: Node) -> void:
	SoundManager.play_pickup()
	if player.has_method("toggle_note"):
		player.toggle_note(title + ":\n" + lore_text)
