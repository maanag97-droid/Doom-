extends RigidBody3D

var damage: int = 85
var explosion_force: float = 30.0
var blood_scene := preload("res://BloodSplatter.tscn")

func _ready() -> void:
	if has_node("Fuse"):
		if not $Fuse.timeout.is_connected(_on_Fuse_timeout):
			$Fuse.timeout.connect(_on_Fuse_timeout)
		$Fuse.wait_time = 2.0
		$Fuse.one_shot = true
		$Fuse.start()

func _on_Fuse_timeout() -> void:
	explode()

func explode() -> void:
	SoundManager.play_explode()
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position

	if has_node("BlastRadius"):
		var bodies = $BlastRadius.get_overlapping_bodies()
		for body in bodies:
			if body == self:
				continue
			if body.has_method("take_damage"):
				body.take_damage(damage)
			if body is CharacterBody3D and "velocity" in body:
				var dir: Vector3 = (body.global_position - global_position).normalized()
				body.velocity += (dir + Vector3(0, 0.5, 0)) * explosion_force
			elif body is RigidBody3D:
				var dir2: Vector3 = (body.global_position - global_position).normalized()
				body.apply_central_impulse((dir2 + Vector3(0, 0.5, 0)) * explosion_force)
	queue_free()
