extends StaticBody3D

var is_open: bool = false
var target_y: float = 0.0

func _ready() -> void:
	target_y = position.y
	if has_node("TriggerZone"):
		var tz: Area3D = $TriggerZone
		if not tz.body_entered.is_connected(_on_TriggerZone_body_entered):
			tz.body_entered.connect(_on_TriggerZone_body_entered)

func _physics_process(delta: float) -> void:
	if is_open:
		position.y = move_toward(position.y, target_y - 4.2, 4.0 * delta)
		if position.y <= target_y - 4.0:
			$CollisionShape3D.disabled = true

func interact(player: Node) -> void:
	_try_open(player)

func _on_TriggerZone_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		_try_open(body)

func _try_open(player: Node) -> void:
	if is_open:
		return
	if player.get("has_blue_key") == true or Global.has_blue_key:
		is_open = true
		SoundManager.play_door()
		if player.has_method("show_banner"):
			player.show_banner("ACCESS GRANTED - BLUE DOOR OPENED!")
	else:
		if player.has_method("show_banner"):
			player.show_banner("LOCKED! Find the Blue Key Sphere or pull the #7734 Vault Lever!")
