extends CharacterBody3D

@export var role: String = "warrior" # "warrior", "mage", "rogue", "minion", "boss"
@export var max_health: int = 80
var health: int = 80
var move_speed: float = 4.6
var attack_range: float = 2.4
var damage: int = 12
var gravity: float = 26.0
var is_grabbed: bool = false
var is_dead: bool = false
var atk_cd: float = 0.0
var special_cd: float = 2.0
var player: Node3D = null
var vis: Node3D = null
var hp_label: Label3D = null
var blood_scene := preload("res://BloodSplatter.tscn")
var coin_script := preload("res://Coin.gd")

func _ready() -> void:
	add_to_group("Enemy")
	add_to_group("enemies")
	if role == "boss":
		add_to_group("Boss")
	vis = load("res://scripts/EnemyVisual.gd").new()
	var title_str := "Skeleton Warrior"
	var lbl_color := Color(1.0, 0.45, 0.35)
	match role:
		"warrior":
			max_health = 95; move_speed = 4.4; damage = 14; attack_range = 2.5
			vis.model_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Warrior.glb"
			vis.skin_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Warrior_skeleton_texture.png"
			vis.model_scale = Vector3(1.0, 1.0, 1.0)
			title_str = "Skeleton Shield-Warrior"
		"mage":
			max_health = 60; move_speed = 3.8; damage = 15; attack_range = 10.5
			vis.model_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Mage.glb"
			vis.skin_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Mage_skeleton_texture.png"
			vis.model_scale = Vector3(0.95, 0.95, 0.95)
			title_str = "Skeleton Dark Mage"
			lbl_color = Color(0.55, 0.7, 1.0)
		"rogue":
			max_health = 55; move_speed = 6.2; damage = 18; attack_range = 2.2
			vis.model_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Rogue.glb"
			vis.skin_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Rogue_skeleton_texture.png"
			vis.model_scale = Vector3(0.92, 0.92, 0.92)
			title_str = "Stealth Rogue Assassin"
			lbl_color = Color(0.85, 0.45, 1.0)
		"minion":
			max_health = 35; move_speed = 6.8; damage = 8; attack_range = 2.0
			vis.model_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Minion.glb"
			vis.skin_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Minion_skeleton_texture.png"
			vis.model_scale = Vector3(0.82, 0.82, 0.82)
			title_str = "Leaping Skeleton Minion"
			lbl_color = Color(0.75, 0.95, 0.45)
		"boss":
			max_health = 260; move_speed = 4.0; damage = 24; attack_range = 3.2
			vis.model_path = "res://assets/characters/kaykit/skeletons/models/Skeleton_Warrior.glb"
			vis.skin_path = "res://assets/characters/kaykit/skeletons/texture/skeleton_texture.png"
			vis.model_scale = Vector3(1.55, 1.55, 1.55)
			title_str = "BOSS: SKELETON WARLORD"
			lbl_color = Color(1.0, 0.85, 0.15)
	health = max_health
	add_child(vis)

	hp_label = Label3D.new()
	hp_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	hp_label.font_size = 38 if role != "boss" else 52
	hp_label.modulate = lbl_color
	hp_label.position = Vector3(0, 2.3 if role != "boss" else 3.2, 0)
	hp_label.text = title_str + " [" + str(health) + " HP]"
	add_child(hp_label)

func _update_label() -> void:
	if hp_label:
		hp_label.text = role.to_upper() + " [" + str(maxi(0, health)) + "/" + str(max_health) + " HP]"

func _physics_process(delta: float) -> void:
	if is_dead or is_grabbed:
		return
	atk_cd = maxf(atk_cd - delta, 0.0)
	special_cd = maxf(special_cd - delta, 0.0)

	# Thrown / Kicked flying physics
	if velocity.length() > 12.0:
		velocity.y -= gravity * delta
		velocity.x = lerpf(velocity.x, 0.0, 1.5 * delta)
		velocity.z = lerpf(velocity.z, 0.0, 1.5 * delta)
		move_and_slide()
		if is_on_wall():
			take_damage(60)
			velocity = Vector3.ZERO
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1

	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]

	if is_instance_valid(player):
		var diff: Vector3 = player.global_position - global_position
		diff.y = 0.0
		var dist: float = diff.length()
		var dir: Vector3 = diff.normalized() if dist > 0.05 else Vector3.FORWARD
		if vis and dir.length() > 0.01:
			vis.rotation.y = atan2(dir.x, dir.z)

		if role == "mage":
			if dist < 4.0:
				velocity.x = -dir.x * move_speed
				velocity.z = -dir.z * move_speed
				if vis: vis.play(vis.Anim.WALK)
			elif dist > attack_range:
				velocity.x = dir.x * move_speed
				velocity.z = dir.z * move_speed
				if vis: vis.play(vis.Anim.WALK)
			else:
				var strafe: Vector3 = dir.cross(Vector3.UP) * sin(Time.get_ticks_msec() * 0.002) * move_speed
				velocity.x = strafe.x
				velocity.z = strafe.z
				if vis: vis.play(vis.Anim.IDLE)
				if atk_cd <= 0.0:
					atk_cd = 2.0
					_fire_magic_orb(dir)
		else:
			if dist > attack_range:
				var spd: float = move_speed
				# Warrior charge or Minion leap
				if role == "warrior" and special_cd <= 0.0 and dist < 9.0:
					spd = move_speed * 2.1
					special_cd = 4.5
				elif role == "minion" and special_cd <= 0.0 and dist < 7.0 and is_on_floor():
					velocity.y = 8.5
					special_cd = 3.0
				elif role == "rogue" and special_cd <= 0.0 and dist < 8.0 and dist > 3.5:
					# Rogue blink step
					global_position += dir * 3.0
					special_cd = 5.0
				velocity.x = dir.x * spd
				velocity.z = dir.z * spd
				if vis: vis.play(vis.Anim.WALK)
			else:
				velocity.x = 0.0
				velocity.z = 0.0
				if vis: vis.play(vis.Anim.ATTACK)
				if atk_cd <= 0.0:
					atk_cd = 1.1
					if player.has_method("take_damage"):
						player.take_damage(damage)

	move_and_slide()

func _fire_magic_orb(dir: Vector3) -> void:
	if vis:
		vis.play(vis.Anim.ATTACK)
	SoundManager.play_pistol()
	var orb := Area3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.28; sm.height = 0.56
	var mi := MeshInstance3D.new()
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.45, 0.3, 1.0)
	mi.set_surface_override_material(0, mat)
	orb.add_child(mi)
	var cs := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = 0.35
	cs.shape = sp
	orb.add_child(cs)
	get_tree().current_scene.add_child(orb)
	orb.global_position = global_position + Vector3(0, 1.4, 0) + dir * 0.9
	var target_pt: Vector3 = orb.global_position + dir * 22.0
	var tw := orb.create_tween()
	tw.tween_property(orb, "global_position", target_pt, 1.6)
	tw.tween_callback(orb.queue_free)
	orb.body_entered.connect(func(b: Node):
		if b.is_in_group("Player") and b.has_method("take_damage"):
			b.take_damage(damage)
			orb.queue_free()
	)

func take_hit(amount: int) -> void:
	take_damage(amount)

func take_damage(amount: float) -> void:
	if is_dead:
		return
	health -= int(amount)
	_update_label()
	SoundManager.play_enemy_hit()
	if vis:
		vis.play(vis.Anim.HURT)
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position + Vector3(0, 1.1, 0)
	if health <= 0:
		_die()

func _die() -> void:
	if is_dead:
		return
	is_dead = true
	SoundManager.play_enemy_die()
	var msg: String = Global.register_kill()
	if is_instance_valid(player) and player.has_method("show_banner"):
		player.show_banner(msg)
	if vis:
		vis.play(vis.Anim.DEATH)
	$CollisionShape3D.set_deferred("disabled", true)
	# Drop 2-4 magnet gold coins!
	var coin_count: int = 5 if role == "boss" else 2
	for i in range(coin_count):
		var c := Area3D.new()
		c.set_script(coin_script)
		c.value = 15 if role == "boss" else 5
		get_tree().current_scene.add_child(c)
		c.global_position = global_position + Vector3(randf_range(-0.8, 0.8), 0.8, randf_range(-0.8, 0.8))
	await get_tree().create_timer(2.2).timeout
	if is_instance_valid(self):
		queue_free()
