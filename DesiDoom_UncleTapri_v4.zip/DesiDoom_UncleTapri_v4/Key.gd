extends Area3D

var base_y: float = 0.0
var t: float = 0.0

func _ready() -> void:
	base_y = position.y
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	t += delta * 3.5
	rotate_y(3.0 * delta)
	position.y = base_y + sin(t) * 0.18

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		body.has_blue_key = true
		Global.has_blue_key = true
		SoundManager.play_pickup()
		if body.has_method("obtain_blue_key"):
			body.obtain_blue_key()
		queue_free()
