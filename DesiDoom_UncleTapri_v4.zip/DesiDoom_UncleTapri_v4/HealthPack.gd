extends Area3D

var heal_amount: int = 30
var base_y: float = 0.0
var t: float = 0.0

func _ready() -> void:
	base_y = position.y
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	t += delta * 3.0
	rotate_y(2.2 * delta)
	position.y = base_y + sin(t) * 0.15

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		if body.current_health < body.max_health:
			if body.has_method("heal"):
				body.heal(heal_amount)
			SoundManager.play_pickup()
			queue_free()
