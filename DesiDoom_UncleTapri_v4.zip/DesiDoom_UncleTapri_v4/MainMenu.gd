extends Control

func _ready() -> void:
	$BtnPlay.pressed.connect(func():
		SoundManager.play_pickup()
		get_tree().change_scene_to_file("res://World.tscn")
	)
	$BtnMarket.pressed.connect(func():
		SoundManager.play_pickup()
		get_tree().change_scene_to_file("res://Market.tscn")
	)
