extends RigidBody3D

var damage: int = 95
var explosion_force: float = 34.0
var blood_scene := preload("res://BloodSplatter.tscn")

func _ready() -> void:
	for c in get_children():
		if c is Sprite3D or c is AnimatedSprite3D:
			c.visible = false
	var m := _load_glb("res://models/weapons_3d/Sutli_Bomb_3D.glb")
	if m:
		m.scale = Vector3(1.5, 1.5, 1.5)
		add_child(m)
	if has_node("Fuse"):
		if not $Fuse.timeout.is_connected(_on_Fuse_timeout):
			$Fuse.timeout.connect(_on_Fuse_timeout)
		$Fuse.wait_time = 1.8
		$Fuse.one_shot = true
		$Fuse.start()

func _load_glb(path: String) -> Node3D:
	if ResourceLoader.exists(path):
		var res = load(path)
		if res is PackedScene:
			return res.instantiate() as Node3D
	var abs_p := ProjectSettings.globalize_path(path)
	if FileAccess.file_exists(path) or FileAccess.file_exists(abs_p):
		var doc := GLTFDocument.new()
		var state := GLTFState.new()
		var use_p := abs_p if FileAccess.file_exists(abs_p) else path
		if doc.append_from_file(use_p, state) == OK:
			return doc.generate_scene(state) as Node3D
	return null

func _on_Fuse_timeout() -> void:
	explode()

func explode() -> void:
	SoundManager.play_explode()
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position

	if has_node("BlastRadius"):
		var bodies = $BlastRadius.get_overlapping_bodies()
		for body in bodies:
			if body == self:
				continue
			if body.has_method("take_damage"):
				body.take_damage(damage)
			if body is CharacterBody3D and "velocity" in body:
				var dir: Vector3 = (body.global_position - global_position).normalized()
				body.velocity += (dir + Vector3(0, 0.5, 0)) * explosion_force
			elif body is RigidBody3D:
				var dir2: Vector3 = (body.global_position - global_position).normalized()
				body.apply_central_impulse((dir2 + Vector3(0, 0.5, 0)) * explosion_force)
	queue_free()
