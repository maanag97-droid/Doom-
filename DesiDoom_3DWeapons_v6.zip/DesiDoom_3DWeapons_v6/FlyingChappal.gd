extends Area3D

var speed: float = 34.0
var damage: int = 65
var return_to_player: bool = false
var life_t: float = 0.0
var player_ref: Node3D = null
var target_enemy: Node3D = null
var model_file: String = "res://models/weapons_3d/Chappal_3D.glb"
var blood_scene := preload("res://BloodSplatter.tscn")

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	# Hide any legacy 2D Sprite3D child and spawn real 3D .glb model
	for c in get_children():
		if c is Sprite3D or c is AnimatedSprite3D:
			c.visible = false
	var m := _load_glb(model_file)
	if m:
		m.scale = Vector3(1.6, 1.6, 1.6)
		add_child(m)
	var best_d: float = 28.0
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and e is Node3D:
			var d: float = global_position.distance_to(e.global_position)
			if d < best_d:
				best_d = d
				target_enemy = e

func _load_glb(path: String) -> Node3D:
	if ResourceLoader.exists(path):
		var res = load(path)
		if res is PackedScene:
			return res.instantiate() as Node3D
	var abs_p := ProjectSettings.globalize_path(path)
	if FileAccess.file_exists(path) or FileAccess.file_exists(abs_p):
		var doc := GLTFDocument.new()
		var state := GLTFState.new()
		var use_p := abs_p if FileAccess.file_exists(abs_p) else path
		if doc.append_from_file(use_p, state) == OK:
			return doc.generate_scene(state) as Node3D
	return null

func _physics_process(delta: float) -> void:
	life_t += delta
	rotate_y(20.0 * delta)
	rotate_x(8.0 * delta)
	if life_t > 0.65:
		return_to_player = true
	if life_t > 1.8:
		queue_free()
		return

	if not return_to_player:
		if is_instance_valid(target_enemy):
			var aim_pos: Vector3 = target_enemy.global_position + Vector3(0, 1.0, 0)
			var dir: Vector3 = (aim_pos - global_position).normalized()
			global_position += dir * speed * delta
		else:
			global_position -= global_transform.basis.z * speed * delta
	else:
		if is_instance_valid(player_ref):
			var back_dir: Vector3 = (player_ref.global_position + Vector3(0, 1.2, 0) - global_position)
			if back_dir.length() < 1.5:
				queue_free()
				return
			global_position += back_dir.normalized() * (speed * 1.2) * delta

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Player"):
		return
	if body.has_method("take_damage"):
		body.take_damage(damage)
		SoundManager.play_punch()
		var sp = blood_scene.instantiate()
		get_tree().current_scene.add_child(sp)
		sp.global_position = global_position
		if is_instance_valid(player_ref) and player_ref.has_method("show_banner"):
			player_ref.show_banner("PATT SE HEADSHOT! 3D BOOMERANG HIT!")
		return_to_player = true
