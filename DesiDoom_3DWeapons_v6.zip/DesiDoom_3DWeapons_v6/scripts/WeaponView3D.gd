extends Node3D

const WEAPON_GLBS := {
	1: "res://models/weapons_3d/Pichkari_Blaster_3D.glb",
	2: "res://models/weapons_3d/Cricket_Bat_3D.glb",
	3: "res://models/weapons_3d/Belan_3D.glb",
	4: "res://models/weapons_3d/Lathi_Danda_3D.glb",
	5: "res://models/weapons_3d/Chappal_3D.glb",
	6: "res://models/weapons_3d/VIP_Horn_Blaster_3D.glb",
	7: "res://models/weapons_3d/Cutting_Chai_Kettle_3D.glb",
	8: "res://models/weapons_3d/Sutli_Bomb_3D.glb",
}

const WEAPON_TRANSFORMS := {
	1: [Vector3(0.28, -0.24, -0.48), Vector3(0, 180, 0), Vector3(0.85, 0.85, 0.85)],
	2: [Vector3(0.32, -0.38, -0.52), Vector3(-18, -25, 12), Vector3(0.68, 0.68, 0.68)],
	3: [Vector3(0.30, -0.26, -0.48), Vector3(-15, 0, 20), Vector3(0.78, 0.78, 0.78)],
	4: [Vector3(0.32, -0.42, -0.52), Vector3(-15, -20, 10), Vector3(0.65, 0.65, 0.65)],
	5: [Vector3(0.28, -0.24, -0.45), Vector3(25, -155, -15), Vector3(0.95, 0.95, 0.95)],
	6: [Vector3(0.28, -0.25, -0.48), Vector3(0, 180, 0), Vector3(0.85, 0.85, 0.85)],
	7: [Vector3(0.28, -0.28, -0.46), Vector3(8, -125, 0), Vector3(0.85, 0.85, 0.85)],
	8: [Vector3(0.26, -0.24, -0.44), Vector3(0, 0, 0), Vector3(0.85, 0.85, 0.85)],
}

var _holder: Node3D = null
var _models: Dictionary = {}
var _cur_slot: int = 1
var _base_pos := Vector3(0.28, -0.24, -0.48)
var _base_rot := Vector3.ZERO
var _bob_t: float = 0.0
var _anim_busy: bool = false

func _ready() -> void:
	_holder = Node3D.new()
	_holder.name = "Holder3D"
	add_child(_holder)
	for slot in WEAPON_GLBS.keys():
		var m := _load_glb(WEAPON_GLBS[slot])
		if m:
			m.visible = false
			_holder.add_child(m)
			_models[slot] = m
	equip_slot(1)

func _load_glb(path: String) -> Node3D:
	if ResourceLoader.exists(path):
		var res = load(path)
		if res is PackedScene:
			return res.instantiate() as Node3D
	var abs_p := ProjectSettings.globalize_path(path)
	if FileAccess.file_exists(path) or FileAccess.file_exists(abs_p):
		var doc := GLTFDocument.new()
		var state := GLTFState.new()
		var use_p := abs_p if FileAccess.file_exists(abs_p) else path
		if doc.append_from_file(use_p, state) == OK:
			return doc.generate_scene(state) as Node3D
	return null

func equip_slot(slot: int) -> void:
	_cur_slot = slot
	for k in _models.keys():
		_models[k].visible = (k == slot)
	if WEAPON_TRANSFORMS.has(slot):
		var t: Array = WEAPON_TRANSFORMS[slot]
		_base_pos = t[0]
		_base_rot = t[1]
		if _models.has(slot):
			_models[slot].scale = t[2]
		_holder.position = _base_pos - Vector3(0, 0.14, 0)
		_holder.rotation_degrees = _base_rot + Vector3(-25, 0, 0)
		var tw := create_tween()
		tw.set_parallel(true)
		tw.tween_property(_holder, "position", _base_pos, 0.14)
		tw.tween_property(_holder, "rotation_degrees", _base_rot, 0.14)

func update_bob(delta: float, moving: bool) -> void:
	if _anim_busy or not _holder:
		return
	if moving:
		_bob_t += delta * 10.5
		var ox := sin(_bob_t) * 0.022
		var oy := abs(cos(_bob_t)) * 0.018
		_holder.position = _holder.position.lerp(_base_pos + Vector3(ox, -oy, 0), 12.0 * delta)
	else:
		_bob_t += delta * 2.2
		var idle_y := sin(_bob_t) * 0.006
		_holder.position = _holder.position.lerp(_base_pos + Vector3(0, idle_y, 0), 10.0 * delta)
	_holder.rotation_degrees = _holder.rotation_degrees.lerp(_base_rot, 12.0 * delta)

func play_attack(slot: int) -> void:
	if not _holder:
		return
	_anim_busy = true
	var tw := create_tween()
	if slot in [2, 3, 4, 5]:
		# 3D Melee / Throw Swing Arc
		tw.tween_property(_holder, "rotation_degrees", _base_rot + Vector3(22, 18, -25), 0.07)
		tw.tween_property(_holder, "position", _base_pos + Vector3(-0.14, 0.05, -0.18), 0.08)
		tw.parallel().tween_property(_holder, "rotation_degrees", _base_rot + Vector3(-55, -35, 38), 0.09)
		tw.tween_property(_holder, "position", _base_pos, 0.14)
		tw.parallel().tween_property(_holder, "rotation_degrees", _base_rot, 0.14)
	else:
		# 3D Blaster / Kettle Recoil & Kickback
		tw.tween_property(_holder, "position", _base_pos + Vector3(0.0, 0.04, 0.11), 0.06)
		tw.parallel().tween_property(_holder, "rotation_degrees", _base_rot + Vector3(18, 0, 0), 0.06)
		tw.tween_property(_holder, "position", _base_pos, 0.16)
		tw.parallel().tween_property(_holder, "rotation_degrees", _base_rot, 0.16)
	tw.tween_callback(func(): _anim_busy = false)

func play_grenade_toss() -> void:
	var prev := _cur_slot
	equip_slot(8)
	play_attack(5)
	get_tree().create_timer(0.32).timeout.connect(func():
		if is_inside_tree():
			equip_slot(prev)
	)
