extends Node3D

enum Anim { IDLE, WALK, ATTACK, HURT, DEATH }

@export var model_path: String = "res://models/characters_3d/Sharma_Uncle_3D.glb"
@export var skin_path: String = ""
@export var model_scale: Vector3 = Vector3(1.05, 1.05, 1.05)

const A_MOVEMENT := "res://assets/characters/kaykit/animations/Rig_Medium_MovementBasic.glb"
const A_COMBAT   := "res://assets/characters/kaykit/animations/Rig_Medium_CombatMelee.glb"
const A_GENERAL  := "res://assets/characters/kaykit/animations/Rig_Medium_General.glb"

const N_IDLE   := "Idle_A"
const N_RUN    := "Running_A"
const N_ATTACK := "Melee_1H_Attack_Chop"
const N_HURT   := "Hit_A"
const N_DEATH  := "Death_A"

var _state: Anim = Anim.IDLE
var _t: float = 0.0
var _dead: bool = false
var _ap: AnimationPlayer = null
var _cur: String = ""
var _body: Node3D = null

func _ready() -> void:
	_boot_glb()

func _instantiate_glb(path: String) -> Node3D:
	if ResourceLoader.exists(path):
		var res = load(path)
		if res is PackedScene:
			return res.instantiate() as Node3D
	var abs_p := ProjectSettings.globalize_path(path)
	if FileAccess.file_exists(path) or FileAccess.file_exists(abs_p):
		var doc := GLTFDocument.new()
		var state := GLTFState.new()
		var use_p := abs_p if FileAccess.file_exists(abs_p) else path
		if doc.append_from_file(use_p, state) == OK:
			return doc.generate_scene(state) as Node3D
	return null

func _boot_glb() -> bool:
	_body = _instantiate_glb(model_path)
	if not _body:
		return false
	_body.scale = model_scale
	add_child(_body)
	if skin_path != "" and ResourceLoader.exists(skin_path):
		_skin(_body, load(skin_path) as Texture2D)
	var skel := _find(_body, "Skeleton3D") as Skeleton3D
	if skel:
		_ap = AnimationPlayer.new()
		skel.get_parent().add_child(_ap)
		_ap.root_node = _ap.get_path_to(skel)
		var lib := AnimationLibrary.new()
		_load_anim(lib, A_GENERAL,  N_IDLE,   "idle")
		_load_anim(lib, A_MOVEMENT, N_RUN,    "run")
		_load_anim(lib, A_COMBAT,   N_ATTACK, "attack")
		_load_anim(lib, A_GENERAL,  N_HURT,   "hurt")
		_load_anim(lib, A_GENERAL,  N_DEATH,  "death")
		if not lib.get_animation_list().is_empty():
			_ap.add_animation_library("", lib)
			_ap.play("idle")
			_cur = "idle"
	return true

func _load_anim(lib: AnimationLibrary, glb: String, anim_name: String, key: String) -> void:
	var tmp := _instantiate_glb(glb)
	if not tmp:
		return
	var src := _find_ap(tmp)
	if src and src.has_animation(anim_name):
		var clip := src.get_animation(anim_name).duplicate(true) as Animation
		for i in clip.get_track_count():
			var p: String = str(clip.track_get_path(i))
			if ":" in p:
				clip.track_set_path(i, NodePath(".:" + p.split(":")[1]))
		lib.add_animation(key, clip)
	tmp.free()

func play(a: Anim) -> void:
	if _dead and a != Anim.DEATH:
		return
	if a == Anim.DEATH:
		_dead = true
	if _state == a and a != Anim.HURT:
		return
	_state = a
	_t = 0.0
	if _ap:
		match a:
			Anim.IDLE:   _clip("idle",   true)
			Anim.WALK:   _clip("run",    true)
			Anim.ATTACK: _clip("attack", false)
			Anim.HURT:   _clip("hurt",   false)
			Anim.DEATH:  _clip("death",  false)

func _clip(anim_key: String, looping: bool) -> void:
	if not _ap or not is_inside_tree():
		return
	if _cur == anim_key and (looping or _ap.is_playing()):
		return
	if _ap.has_animation(anim_key):
		var anim := _ap.get_animation(anim_key)
		if anim:
			anim.loop_mode = Animation.LOOP_LINEAR if looping else Animation.LOOP_NONE
		_ap.play(anim_key)
		_cur = anim_key

func _find(node: Node, cls: String) -> Node:
	if node.get_class() == cls:
		return node
	for c in node.get_children():
		var r := _find(c, cls)
		if r:
			return r
	return null

func _find_ap(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for c in node.get_children():
		var r := _find_ap(c)
		if r:
			return r
	return null

func _skin(node: Node, tex: Texture2D) -> void:
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		for i in mi.get_surface_override_material_count():
			var m = mi.get_active_material(i)
			if m is BaseMaterial3D:
				var m2 := m.duplicate() as StandardMaterial3D
				if m2:
					m2.albedo_texture = tex
					mi.set_surface_override_material(i, m2)
	for c in node.get_children():
		_skin(c, tex)
