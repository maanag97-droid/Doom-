extends CharacterBody3D

@export var char_type: String = "havaldar" # "havaldar", "aunty", "pahalwan", "gabru"
var health: int = 90
var move_speed: float = 5.0
var gravity: float = 28.0
var is_grabbed: bool = false
var _dead: bool = false
var atk_cd: float = 0.0
var player: Node3D = null
var _vis: Node3D = null
var _lbl: Label3D = null
var blood_scene := preload("res://BloodSplatter.tscn")
var coin_script := preload("res://Coin.gd")

func _ready() -> void:
	add_to_group("Enemy")
	add_to_group("enemies")
	_vis = load("res://scripts/EnemyVisual.gd").new()
	_vis.skin_path = ""
	_lbl = Label3D.new()
	match char_type:
		"aunty":
			health = 80
			move_speed = 5.4
			_vis.model_path = "res://models/characters_3d/Belan_Aunty_3D.glb"
			_vis.model_scale = Vector3(1.0, 1.0, 1.0)
			_lbl.text = "3D BELAN AUNTY [80 HP]"
			_lbl.modulate = Color(1.0, 0.45, 0.75)
		"pahalwan":
			health = 135
			move_speed = 4.4
			_vis.model_path = "res://models/characters_3d/Dara_Pahalwan_3D.glb"
			_vis.model_scale = Vector3(1.18, 1.18, 1.18)
			_lbl.text = "3D DARA PAHALWAN [135 HP]"
			_lbl.modulate = Color(1.0, 0.35, 0.25)
		"gabru":
			health = 95
			move_speed = 5.6
			_vis.model_path = "res://models/characters_3d/Punjabi_Gabru_3D.glb"
			_vis.model_scale = Vector3(1.06, 1.06, 1.06)
			_lbl.text = "3D PUNJABI GABRU [95 HP]"
			_lbl.modulate = Color(1.0, 0.85, 0.25)
		_:
			health = 95
			move_speed = 4.9
			_vis.model_path = "res://models/characters_3d/Havaldar_3D.glb"
			_vis.model_scale = Vector3(1.06, 1.06, 1.06)
			_lbl.text = "3D DANDA HAVALDAR JI [95 HP]"
			_lbl.modulate = Color(1.0, 0.88, 0.38)
	add_child(_vis)
	_lbl.font_size = 38
	_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_lbl.position = Vector3(0, 2.45, 0)
	add_child(_lbl)

func _physics_process(delta: float) -> void:
	if _dead or is_grabbed:
		return
	atk_cd = maxf(atk_cd - delta, 0.0)
	if velocity.length() > 12.0:
		velocity.y -= gravity * delta
		velocity.x = lerpf(velocity.x, 0.0, 1.5 * delta)
		velocity.z = lerpf(velocity.z, 0.0, 1.5 * delta)
		move_and_slide()
		if is_on_wall():
			take_damage(55)
			velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1
	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]
	if is_instance_valid(player):
		var diff: Vector3 = player.global_position - global_position
		diff.y = 0.0
		var dist: float = diff.length()
		var dir: Vector3 = diff.normalized() if dist > 0.05 else Vector3.FORWARD
		if _vis and dir.length() > 0.01:
			_vis.rotation.y = atan2(dir.x, dir.z)
		if dist > 2.2:
			velocity.x = dir.x * move_speed
			velocity.z = dir.z * move_speed
			if _vis:
				_vis.play(_vis.Anim.WALK)
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			if _vis:
				_vis.play(_vis.Anim.ATTACK)
			if atk_cd <= 0.0 and player.has_method("take_damage"):
				atk_cd = 1.0
				player.take_damage(16 if char_type == "pahalwan" else 13)
				if player.has_method("show_banner"):
					match char_type:
						"aunty": player.show_banner("3D BELAN SMASH! MERE GHAR KE SAMNE SHOR MAT KAR!")
						"pahalwan": player.show_banner("AKHADA KUSHTI SMASH! DARA PAHALWAN ATTACK!")
						"gabru": player.show_banner("BURRAAH! PUNJABI GABRU LATHI STRIKE!")
						_: player.show_banner("3D LATHI CHARGE! TERA CHALLAN KATEGA RS 1000!")
	move_and_slide()

func take_damage(amount: float) -> void:
	if _dead:
		return
	health -= int(amount)
	SoundManager.play_enemy_hit()
	if _vis:
		_vis.play(_vis.Anim.HURT)
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position + Vector3(0, 1.1, 0)
	if health <= 0:
		_dead = true
		velocity = Vector3.ZERO
		if _vis:
			_vis.play(_vis.Anim.DEATH)
		SoundManager.play_enemy_die()
		var msg: String = Global.register_kill()
		if is_instance_valid(player) and player.has_method("show_banner"):
			player.show_banner(msg)
		for i in range(2):
			var c := Area3D.new()
			c.set_script(coin_script)
			c.value = 10
			get_tree().current_scene.add_child(c)
			c.global_position = global_position + Vector3(randf_range(-0.6, 0.6), 0.8, randf_range(-0.6, 0.6))
		await get_tree().create_timer(1.8).timeout
		if is_instance_valid(self):
			queue_free()
