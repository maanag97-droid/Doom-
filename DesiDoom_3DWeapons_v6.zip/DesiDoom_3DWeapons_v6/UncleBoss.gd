extends CharacterBody3D

var health: int = 180
var max_health: int = 180
var move_speed: float = 5.2
var gravity: float = 28.0
var is_grabbed: bool = false
var is_enraged: bool = false
var is_dead: bool = false
var atk_cd: float = 0.0
var ball_cd: float = 1.8
var player: Node3D = null
var lbl: Label3D = null
var _vis: Node3D = null
var blood_scene := preload("res://BloodSplatter.tscn")
var coin_script := preload("res://Coin.gd")

func _ready() -> void:
	add_to_group("Enemy")
	add_to_group("enemies")
	add_to_group("Boss")
	_vis = load("res://scripts/EnemyVisual.gd").new()
	_vis.model_path = "res://models/characters_3d/Sharma_Uncle_3D.glb"
	_vis.skin_path = ""
	_vis.model_scale = Vector3(1.25, 1.25, 1.25)
	add_child(_vis)

	lbl = Label3D.new()
	lbl.text = "3D SHARMA UNCLE (SOCIETY BOSS) [180 HP]"
	lbl.font_size = 44
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(1.0, 0.85, 0.2)
	lbl.position = Vector3(0, 2.75, 0)
	add_child(lbl)

func _physics_process(delta: float) -> void:
	if is_dead or is_grabbed:
		return
	atk_cd = maxf(atk_cd - delta, 0.0)
	ball_cd = maxf(ball_cd - delta, 0.0)
	if velocity.length() > 12.0:
		velocity.y -= gravity * delta
		velocity.x = lerpf(velocity.x, 0.0, 1.5 * delta)
		velocity.z = lerpf(velocity.z, 0.0, 1.5 * delta)
		move_and_slide()
		if is_on_wall():
			take_damage(55)
			velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1
	if not is_instance_valid(player):
		var players = get_tree().get_nodes_in_group("Player")
		if players.size() > 0:
			player = players[0]
	if is_instance_valid(player):
		var diff: Vector3 = player.global_position - global_position
		diff.y = 0.0
		var dist: float = diff.length()
		var dir: Vector3 = diff.normalized() if dist > 0.05 else Vector3.FORWARD
		if _vis and dir.length() > 0.01:
			_vis.rotation.y = atan2(dir.x, dir.z)
		if dist > 2.4:
			var spd: float = move_speed * (1.45 if is_enraged else 1.0)
			velocity.x = dir.x * spd
			velocity.z = dir.z * spd
			if _vis:
				_vis.play(_vis.Anim.WALK)
			if ball_cd <= 0.0 and dist < 16.0:
				ball_cd = 1.6 if is_enraged else 2.5
				_throw_cricket_ball(dir)
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			if _vis:
				_vis.play(_vis.Anim.ATTACK)
			if atk_cd <= 0.0 and player.has_method("take_damage"):
				atk_cd = 0.85 if is_enraged else 1.1
				player.take_damage(22 if is_enraged else 15)
				if player.has_method("show_banner"):
					player.show_banner("SHARMA UNCLE 3D BAT SMASH! NO CRICKET IN SOCIETY - FINE 500!")
	move_and_slide()

func _throw_cricket_ball(dir: Vector3) -> void:
	SoundManager.play_kick()
	var ball := Area3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.22; sm.height = 0.44
	var mi := MeshInstance3D.new()
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.9, 0.1, 0.1)
	mat.roughness = 0.3
	mi.set_surface_override_material(0, mat)
	ball.add_child(mi)
	var cs := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = 0.28
	cs.shape = sp
	ball.add_child(cs)
	get_tree().current_scene.add_child(ball)
	ball.global_position = global_position + Vector3(0, 1.4, 0) + dir * 0.9
	var target_pt: Vector3 = ball.global_position + dir * 24.0
	var tw := ball.create_tween()
	tw.tween_property(ball, "global_position", target_pt, 1.2)
	tw.tween_callback(ball.queue_free)
	ball.body_entered.connect(func(b: Node):
		if b.is_in_group("Player") and b.has_method("take_damage"):
			b.take_damage(14)
			if b.has_method("show_banner"):
				b.show_banner("HIT BY UNCLE'S 3D FAST YORKER CRICKET BALL!")
			ball.queue_free()
	)

func take_damage(amount: float) -> void:
	if is_dead:
		return
	health -= int(amount)
	SoundManager.play_enemy_hit()
	if _vis:
		_vis.play(_vis.Anim.HURT)
	var sp = blood_scene.instantiate()
	get_tree().current_scene.add_child(sp)
	sp.global_position = global_position + Vector3(0, 1.2, 0)
	if health <= 85 and not is_enraged and health > 0:
		is_enraged = true
		health += 35
		if _vis:
			_vis.scale = Vector3(1.15, 1.15, 1.15)
		if lbl:
			lbl.modulate = Color(1.0, 0.25, 0.2)
		SoundManager.play_explode()
		if is_instance_valid(player) and player.has_method("show_banner"):
			player.show_banner("SHARMA UNCLE DRANK RAJU'S GARAM CHAI! PHASE 2 RAGE MODE!")
	if lbl:
		lbl.text = ("ENRAGED 3D SHARMA UNCLE [" if is_enraged else "3D SHARMA UNCLE [") + str(maxi(0, health)) + " HP]"
	if health <= 0:
		_die()

func _die() -> void:
	if is_dead:
		return
	is_dead = true
	velocity = Vector3.ZERO
	SoundManager.play_enemy_die()
	if _vis:
		_vis.play(_vis.Anim.DEATH)
	if lbl:
		lbl.text = "ARRE MERI KAMAR! (UNCLE DEFEATED!)"
		lbl.modulate = Color(1.0, 0.95, 0.3)
	$CollisionShape3D.set_deferred("disabled", true)
	var msg: String = Global.register_kill()
	if is_instance_valid(player) and player.has_method("show_banner"):
		player.show_banner("ARRE MERI KAMAR! 3D UNCLE DEFEATED! " + msg)
	for i in range(5):
		var c := Area3D.new()
		c.set_script(coin_script)
		c.value = 12
		get_tree().current_scene.add_child(c)
		c.global_position = global_position + Vector3(randf_range(-0.9, 0.9), 0.8, randf_range(-0.9, 0.9))
	await get_tree().create_timer(4.0).timeout
	if is_instance_valid(self):
		queue_free()
