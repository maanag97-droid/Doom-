extends CharacterBody3D

signal health_changed(current_value: float)
signal player_died
signal ammo_changed(new_count: int)

@export var projectile_scene: PackedScene = preload("res://Bullet.tscn")
@export var grenade_scene: PackedScene = preload("res://Grenade.tscn")
var chappal_scene: PackedScene = preload("res://FlyingChappal.tscn")

var can_kick: bool = true
const KICK_DAMAGE: int = 42
const KICK_PUSH_FORCE: float = 56.0
var grenade_force: float = 18.0
var can_throw_grenade: bool = true

var trauma: float = 0.0
var trauma_power: float = 2.0
var decay: float = 1.6
var max_roll: float = 8.0
var max_offset := Vector2(0.25, 0.25)

var is_hit_by_car: bool = false
var impact_velocity: Vector3 = Vector3.ZERO
var external_velocity: Vector3 = Vector3.ZERO
var active_grabber: Node = null

var max_health: float = 100.0
var current_health: float = 100.0
var max_ammo: int = 120
var current_ammo: int = 60
var grabbed_enemy: Node3D = null
var has_blue_key: bool = false
var chai_fever_timer: float = 0.0

var base_speed: float = 14.5
var speed: float = 14.5
var gravity: float = 28.0
var jump_strength: float = 11.8
var mouse_sensitivity: float = 0.2
const GRAB_DISTANCE: float = 5.5
const THROW_POWER: float = 65.0

enum { STATE_IDLE, STATE_ATTACKING, STATE_INSPECT }
var state: int = STATE_IDLE
var current_weapon: int = 1
var camera_x_rotation: float = 0.0
var fire_held: bool = false
var fire_touch_index: int = -1
var jump_requested: bool = false
var bob_time: float = 0.0

@onready var head: Camera3D = $Camera3D
@onready var head_ray: RayCast3D = $Camera3D/RayCast3D
@onready var flashlight: SpotLight3D = $Camera3D/SpotLight3D
@onready var muzzle_light: OmniLight3D = $Camera3D/MuzzleLight
@onready var gun_sprite: AnimatedSprite2D = $CanvasLayer/AnimatedSprite2D
@onready var joystick: Control = $MobileControls/Joystick
@onready var look_zone: Control = $MobileControls/TouchLookZone
@onready var note_overlay: ColorRect = $CanvasLayer/NoteOverlay
@onready var note_label: Label = $CanvasLayer/NoteOverlay/NoteLabel
@onready var banner_label: Label = $CanvasLayer/BannerLabel
@onready var key_badge: Label = $CanvasLayer/TopBar/KeyBadge
@onready var kills_label: Label = $CanvasLayer/TopBar/KillsLabel
@onready var coins_label: Label = $CanvasLayer/TopBar/CoinsLabel
@onready var hp_text_label: Label = $CanvasLayer/TopBar/HPText
@onready var damage_flash: ColorRect = $CanvasLayer/DamageFlash
@onready var map_menu: Panel = $CanvasLayer/MapMenu
@onready var chai_shop: Panel = $CanvasLayer/ChaiShop

var weapon_3d: Node3D = null
var weapon_names := {
	1: "1: 3D HOLI PICHKARI BLASTER",
	2: "2: 3D KASHMIR WILLOW BAT",
	3: "3: 3D DEADLY BELAN BOOMERANG",
	4: "4: 3D POLICE LATHI & GRAB",
	5: "5: 3D FLYING CHAPPAL",
	6: "6: 3D VIP HORN BLASTER",
	7: "7: 3D GARAM CHAI KETTLE"
}

func _ready() -> void:
	Engine.time_scale = 1.0
	add_to_group("Player")
	has_blue_key = Global.has_blue_key
	if not DisplayServer.is_touchscreen_available():
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	current_health = max_health
	health_changed.emit(current_health)
	ammo_changed.emit(current_ammo)
	if flashlight:
		flashlight.visible = false
	if muzzle_light:
		muzzle_light.visible = false
	if note_overlay:
		note_overlay.visible = false
	if map_menu:
		map_menu.visible = false
	if chai_shop:
		chai_shop.visible = false
	weapon_3d = load("res://scripts/WeaponView3D.gd").new()
	weapon_3d.name = "WeaponView3D"
	head.add_child(weapon_3d)
	if gun_sprite:
		gun_sprite.visible = false
	_wire_mobile_buttons()
	update_weapon_visuals()
	_update_hud_badges()
	show_banner("DESI DOOM & DUNGEON 3D! Talk to Raju Chaiwala or tap [CHAI SHOP]!")

func _wire_mobile_buttons() -> void:
	var btn_fire: Button = $MobileControls/BtnFire
	btn_fire.button_down.connect(func():
		fire_held = true
		if state == STATE_IDLE:
			start_attack()
	)
	btn_fire.button_up.connect(func(): fire_held = false)

	$MobileControls/BtnKick.pressed.connect(_trigger_kick)
	$MobileControls/BtnGrenade.pressed.connect(_trigger_grenade)
	$MobileControls/BtnJump.pressed.connect(_trigger_jump)
	$MobileControls/BtnUse.pressed.connect(interact_with_object)
	$MobileControls/BtnChaiShop.pressed.connect(toggle_chai_shop)
	$MobileControls/BtnLight.pressed.connect(_trigger_light)
	$MobileControls/BtnBag.pressed.connect(_trigger_bag)
	$MobileControls/BtnMap.pressed.connect(_trigger_map)

	if has_node("CanvasLayer/NoteOverlay/CloseNoteBtn"):
		$CanvasLayer/NoteOverlay/CloseNoteBtn.pressed.connect(hide_note)

	for i in range(1, 8):
		var wb: Button = get_node_or_null("MobileControls/WeaponBar/Wep" + str(i))
		if wb:
			wb.pressed.connect(func(): change_weapon(i))

	if map_menu:
		$CanvasLayer/MapMenu/VBox/BtnWorld.pressed.connect(func(): _travel_to("res://World.tscn", "Main Hall Arena"))
		$CanvasLayer/MapMenu/VBox/BtnLevel1.pressed.connect(func(): _travel_to("res://Level1.tscn", "Toxic Parkour & Skeletons"))
		$CanvasLayer/MapMenu/VBox/BtnCorridor.pressed.connect(func(): _travel_to("res://Level_Corridor.tscn", "Dark Dungeon Corridor"))
		$CanvasLayer/MapMenu/VBox/BtnMarket.pressed.connect(func(): _travel_to("res://Market.tscn", "Night Chai Market & Boss"))
		$CanvasLayer/MapMenu/VBox/BtnDungeon.pressed.connect(func(): _travel_to("res://GridMap.tscn", "Skeleton Crypt Dungeon"))
		$CanvasLayer/MapMenu/VBox/BtnCloseMap.pressed.connect(func(): map_menu.visible = false)

	if chai_shop:
		$CanvasLayer/ChaiShop/VBox/BtnBuyChai.pressed.connect(_buy_cutting_chai)
		$CanvasLayer/ChaiShop/VBox/BtnBuyHorn.pressed.connect(_buy_vip_horn)
		$CanvasLayer/ChaiShop/VBox/BtnBuyAmmo.pressed.connect(_buy_ammo_armor)
		$CanvasLayer/ChaiShop/VBox/BtnCloseShop.pressed.connect(toggle_chai_shop)

func toggle_chai_shop() -> void:
	if chai_shop:
		SoundManager.play_click()
		chai_shop.visible = not chai_shop.visible
		_update_hud_badges()

func _buy_cutting_chai() -> void:
	if Global.coins >= 20:
		Global.coins -= 20
		chai_fever_timer = 14.0
		heal(50)
		SoundManager.play_pickup()
		show_banner("GARAM CHAI KI PYALI HO! 14s CHAI FEVER OVERDRIVE (1.6x SPEED)!")
		toggle_chai_shop()
	else:
		show_banner("Need 20 Coins! Kill skeletons or open Golden Chests!")

func _buy_vip_horn() -> void:
	if Global.coins >= 30:
		Global.coins -= 30
		Global.vip_horn_unlocked = true
		SoundManager.play_explode()
		show_banner("VIP PRESSURE HORN UNLOCKED! [KICK] now blasts a sonic shockwave!")
		toggle_chai_shop()
	else:
		show_banner("Need 30 Coins for VIP Pressure Horn!")

func _buy_ammo_armor() -> void:
	if Global.coins >= 15:
		Global.coins -= 15
		max_health += 35.0
		heal(50.0)
		add_ammo(50)
		SoundManager.play_pickup()
		show_banner("BOUGHT +50 AMMO & +35 MAX ARMOR!")
		toggle_chai_shop()
	else:
		show_banner("Need 15 Coins for Ammo & Armor Pack!")

func get_keys() -> int:
	return 1 if (has_blue_key or Global.has_blue_key) else 0

func collect_gem(amount: int) -> void:
	Global.coins += amount
	Global.add_xp(amount * 3)
	_update_hud_badges()

func on_level_up(new_lvl: int) -> void:
	max_health += 15.0
	current_health = max_health
	health_changed.emit(current_health)
	SoundManager.play_pickup()
	show_banner("LEVEL UP! YOU ARE NOW LEVEL " + str(new_lvl) + " (+15 MAX HP)! JALWA HAI HAMARA!")

func _trigger_kick() -> void:
	if active_grabber and active_grabber.has_method("escape_step"):
		active_grabber.escape_step()
	if can_kick and state != STATE_INSPECT:
		perform_quick_kick()

func _trigger_grenade() -> void:
	if can_throw_grenade and state != STATE_INSPECT:
		perform_grenade_throw()

func _trigger_jump() -> void:
	if active_grabber and active_grabber.has_method("escape_step"):
		active_grabber.escape_step()
	jump_requested = true

func _trigger_light() -> void:
	if flashlight:
		flashlight.visible = not flashlight.visible
		SoundManager.play_click()
		show_banner("FLASHLIGHT: " + ("ON" if flashlight.visible else "OFF"))

func _trigger_bag() -> void:
	if has_node("Inventory"):
		SoundManager.play_click()
		$Inventory.toggle()

func _trigger_map() -> void:
	if map_menu:
		SoundManager.play_click()
		map_menu.visible = not map_menu.visible

func _travel_to(scene_path: String, title: String) -> void:
	Global.current_level_name = title
	Global.next_scene_path = scene_path
	get_tree().change_scene_to_file("res://LoadingScreen.tscn")

func show_banner(msg: String) -> void:
	if banner_label:
		banner_label.text = msg
		banner_label.modulate.a = 1.0

func obtain_blue_key() -> void:
	has_blue_key = true
	Global.has_blue_key = true
	if has_node("Inventory"):
		$Inventory.add_item("Blue Key")
	_update_hud_badges()
	show_banner("GOT THE BLUE SECURITY KEY! Open the Blue Door!")

func _update_hud_badges() -> void:
	if key_badge:
		key_badge.text = "KEY: YES" if (has_blue_key or Global.has_blue_key) else "KEY: NO"
		key_badge.modulate = Color(0.3, 0.75, 1.0) if (has_blue_key or Global.has_blue_key) else Color(0.6, 0.6, 0.6)
	if kills_label:
		kills_label.text = "KILLS: " + str(Global.kills) + " (LV" + str(Global.player_level) + ")"
	if coins_label:
		coins_label.text = "COINS: " + str(Global.coins)
	if hp_text_label:
		hp_text_label.text = "HP: " + str(int(ceil(current_health)))

func _input(event: InputEvent) -> void:
	if is_hit_by_car:
		return

	if event is InputEventScreenTouch:
		var pt: Vector2 = event.position
		if event.pressed:
			# If a popup modal is open, let standard UI buttons handle taps inside it
			if (map_menu and map_menu.visible) or (chai_shop and chai_shop.visible) or ($Inventory and $Inventory.visible) or (note_overlay and note_overlay.visible):
				return
			if $MobileControls/BtnFire.get_global_rect().has_point(pt):
				fire_touch_index = event.index
				fire_held = true
				if state == STATE_IDLE:
					start_attack()
				return
			elif $MobileControls/BtnKick.get_global_rect().has_point(pt):
				_trigger_kick()
				return
			elif $MobileControls/BtnGrenade.get_global_rect().has_point(pt):
				_trigger_grenade()
				return
			elif $MobileControls/BtnJump.get_global_rect().has_point(pt):
				_trigger_jump()
				return
			elif $MobileControls/BtnUse.get_global_rect().has_point(pt):
				interact_with_object()
				return
			elif $MobileControls/BtnChaiShop.get_global_rect().has_point(pt):
				toggle_chai_shop()
				return
			elif $MobileControls/BtnLight.get_global_rect().has_point(pt):
				_trigger_light()
				return
			elif $MobileControls/BtnBag.get_global_rect().has_point(pt):
				_trigger_bag()
				return
			elif $MobileControls/BtnMap.get_global_rect().has_point(pt):
				_trigger_map()
				return
			for i in range(1, 8):
				var wb: Button = get_node_or_null("MobileControls/WeaponBar/Wep" + str(i))
				if wb and wb.get_global_rect().has_point(pt):
					change_weapon(i)
					return
		else:
			if event.index == fire_touch_index:
				fire_touch_index = -1
				fire_held = false

	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		rotate_y(deg_to_rad(-event.relative.x * mouse_sensitivity))
		camera_x_rotation = clampf(camera_x_rotation - event.relative.y * mouse_sensitivity, -85.0, 85.0)
		head.rotation_degrees.x = camera_x_rotation

	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_F: _trigger_light()
			KEY_E: interact_with_object()
			KEY_C: toggle_chai_shop()
			KEY_I, KEY_TAB: _trigger_bag()
			KEY_Q: _trigger_kick()
			KEY_G: _trigger_grenade()
			KEY_1: change_weapon(1)
			KEY_2: change_weapon(2)
			KEY_3: change_weapon(3)
			KEY_4: change_weapon(4)
			KEY_5: change_weapon(5)
			KEY_6: change_weapon(6)
			KEY_7: change_weapon(7)
			KEY_M, KEY_ESCAPE: _trigger_map()

func add_trauma(amount: float) -> void:
	trauma = minf(trauma + amount, 1.0)

func _physics_process(delta: float) -> void:
	_update_hud_badges()
	if chai_fever_timer > 0.0:
		chai_fever_timer -= delta
		speed = base_speed * 1.55
	else:
		speed = base_speed

	if banner_label and banner_label.modulate.a > 0.0:
		banner_label.modulate.a = maxf(0.0, banner_label.modulate.a - delta * 0.25)
	if damage_flash and damage_flash.color.a > 0.0:
		damage_flash.color.a = maxf(0.0, damage_flash.color.a - delta * 1.8)

	if global_position.y < -30.0:
		global_position = Vector3(0.0, 4.0, 0.0)
		velocity = Vector3.ZERO
		show_banner("Respawned back on arena floor!")

	if is_hit_by_car:
		impact_velocity.y -= gravity * delta
		impact_velocity.x = lerpf(impact_velocity.x, 0.0, 2.0 * delta)
		impact_velocity.z = lerpf(impact_velocity.z, 0.0, 2.0 * delta)
		velocity = impact_velocity
		move_and_slide()
		add_trauma(0.04)
		return

	var input_vec := Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): input_vec.y += 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): input_vec.y -= 1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): input_vec.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): input_vec.x += 1.0

	if joystick and joystick.has_method("get_value"):
		var joy_val: Vector2 = joystick.get_value()
		if joy_val.length() > 0.05:
			input_vec = Vector2(joy_val.x, -joy_val.y)

	if input_vec.length() > 1.0:
		input_vec = input_vec.normalized()

	var forward: Vector3 = global_transform.basis.z
	var right: Vector3 = global_transform.basis.x
	var direction: Vector3 = (forward * -input_vec.y + right * input_vec.x)

	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1

	if is_on_floor() and (Input.is_key_pressed(KEY_SPACE) or jump_requested):
		velocity.y = jump_strength
		SoundManager.play_jump()
	jump_requested = false

	velocity += external_velocity
	external_velocity = external_velocity.lerp(Vector3.ZERO, 0.12)
	move_and_slide()

	if look_zone and look_zone.has_method("consume_look") and not is_hit_by_car:
		var look_vec: Vector2 = look_zone.consume_look()
		if look_vec != Vector2.ZERO:
			rotate_y(deg_to_rad(-look_vec.x))
			camera_x_rotation = clampf(camera_x_rotation - look_vec.y, -85.0, 85.0)
			head.rotation_degrees.x = camera_x_rotation

	if trauma > 0.0:
		trauma = maxf(trauma - decay * delta, 0.0)
		var amount: float = pow(trauma, trauma_power)
		head.rotation_degrees.z = max_roll * amount * randf_range(-1.0, 1.0)
		head.h_offset = max_offset.x * amount * randf_range(-1.0, 1.0)
		head.v_offset = max_offset.y * amount * randf_range(-1.0, 1.0)
	else:
		head.rotation_degrees.z = lerpf(head.rotation_degrees.z, 0.0, 8.0 * delta)
		head.h_offset = 0.0
		head.v_offset = 0.0

	if weapon_3d and weapon_3d.has_method("update_bob"):
		weapon_3d.update_bob(delta, input_vec.length() > 0.1 and is_on_floor())

	if state == STATE_IDLE and fire_held:
		start_attack()

func change_weapon(num: int) -> void:
	current_weapon = num
	SoundManager.play_click()
	update_weapon_visuals()
	if weapon_names.has(num):
		show_banner("Equipped " + weapon_names[num])
	for i in range(1, 8):
		var wb: Button = get_node_or_null("MobileControls/WeaponBar/Wep" + str(i))
		if wb:
			wb.modulate = Color(1.0, 0.85, 0.25) if i == num else Color(0.85, 0.85, 0.85)

func interact_with_object() -> void:
	if note_overlay and note_overlay.visible:
		hide_note()
		return
	if head_ray and head_ray.is_colliding():
		var obj = head_ray.get_collider()
		if obj and obj.has_method("interact"):
			obj.interact(self)
			return
		elif obj and obj.get_parent() and obj.get_parent().has_method("interact"):
			obj.get_parent().interact(self)
			return
	var best_node: Node3D = null
	var best_dist: float = 4.8
	for node in get_tree().get_nodes_in_group("Interactable"):
		if is_instance_valid(node) and node is Node3D:
			var d: float = global_position.distance_to(node.global_position)
			if d < best_dist:
				best_dist = d
				best_node = node
	if best_node and best_node.has_method("interact"):
		best_node.interact(self)
		return
	show_banner("Walk near Raju Chaiwala, a Golden Chest, Lever, or Note and tap [USE / E]!")

func toggle_note(text_str: String) -> void:
	if note_overlay and note_label:
		note_overlay.visible = not note_overlay.visible
		note_label.text = text_str

func hide_note() -> void:
	if note_overlay:
		note_overlay.visible = false

func update_weapon_visuals() -> void:
	if weapon_3d and weapon_3d.has_method("equip_slot"):
		weapon_3d.equip_slot(current_weapon)
	if gun_sprite:
		gun_sprite.visible = false
	if true:
		return
	gun_sprite.flip_h = false
	match current_weapon:
		1:
			gun_sprite.scale = Vector2(2.6, 2.6)
			gun_sprite.play("default")
		2:
			gun_sprite.scale = Vector2(2.6, 2.6)
			gun_sprite.play("idle_fist")
		3:
			gun_sprite.scale = Vector2(2.2, 2.2)
			gun_sprite.play("hidle")
		4:
			gun_sprite.scale = Vector2(2.3, 2.3)
			if is_instance_valid(grabbed_enemy):
				gun_sprite.play("ghands_hold")
			else:
				gun_sprite.play("ghands")
		5:
			gun_sprite.scale = Vector2(1.9, 1.9)
			gun_sprite.play("chappal_idle")
		6:
			gun_sprite.scale = Vector2(1.85, 1.85)
			gun_sprite.play("vip_horn")
		7:
			gun_sprite.scale = Vector2(1.85, 1.85)
			gun_sprite.play("chai_weapon")

func _flash_muzzle() -> void:
	if muzzle_light:
		muzzle_light.visible = true
		get_tree().create_timer(0.08).timeout.connect(func():
			if is_instance_valid(self) and muzzle_light:
				muzzle_light.visible = false
		)

func start_attack() -> void:
	if state != STATE_IDLE:
		return
	state = STATE_ATTACKING
	if weapon_3d and weapon_3d.has_method("play_attack"):
		weapon_3d.play_attack(current_weapon)
	var cd_mult: float = 0.6 if chai_fever_timer > 0.0 else 1.0
	match current_weapon:
		1: # Shotgun
			if try_spend_ammo(1):
				gun_sprite.frame = 0
				gun_sprite.play("shoot")
				SoundManager.play_shotgun()
				_flash_muzzle()
				fire_projectile(1.5, 38)
				fire_melee(12.0, 32)
				add_trauma(0.35)
			await get_tree().create_timer(0.40 * cd_mult).timeout
		2: # Doom Fist
			gun_sprite.frame = 0
			gun_sprite.play("punch")
			SoundManager.play_punch()
			fire_melee(5.2, 48)
			add_trauma(0.28)
			await get_tree().create_timer(0.28 * cd_mult).timeout
		3: # 3D Deadly Belan Boomerang
			SoundManager.play_punch()
			fire_melee(6.5, 48)
			_spawn_flying_belan()
			add_trauma(0.24)
			await get_tree().create_timer(0.28 * cd_mult).timeout
		4: # Brutal Grab / Throw
			SoundManager.play_kick()
			if not is_instance_valid(grabbed_enemy):
				_try_grab()
			else:
				await _release_and_throw()
			add_trauma(0.35)
			await get_tree().create_timer(0.28).timeout
		5: # Flying Chappal (Slap + Boomerang Throw!)
			gun_sprite.frame = 0
			gun_sprite.play("chappal_swing")
			SoundManager.play_punch()
			fire_melee(6.0, 55)
			_spawn_flying_chappal()
			add_trauma(0.32)
			await get_tree().create_timer(0.32 * cd_mult).timeout
		6: # Golden VIP Triple Air-Horn Blaster
			SoundManager.play_explode()
			_flash_muzzle()
			add_trauma(0.55)
			show_banner("VIP TRIPLE HORN BLASTER! SIDE PLEASE!")
			for e in get_tree().get_nodes_in_group("enemies"):
				if is_instance_valid(e) and global_position.distance_to(e.global_position) < 13.0:
					if e.has_method("take_damage"): e.take_damage(45)
					if "velocity" in e:
						var bdir: Vector3 = (e.global_position - global_position).normalized()
						e.velocity = (bdir + Vector3(0, 0.45, 0)).normalized() * 58.0
			await get_tree().create_timer(0.45 * cd_mult).timeout
		7: # Garam Chai & Parle-G Biscuit Splash
			SoundManager.play_pickup()
			heal(12.0)
			chai_fever_timer = maxf(chai_fever_timer, 5.0)
			fire_melee(10.0, 48)
			add_trauma(0.28)
			show_banner("GARAM CHAI SPLASH + PARLE-G POWER (+12 HP & SPEED BOOST)!")
			await get_tree().create_timer(0.40 * cd_mult).timeout
	state = STATE_IDLE
	update_weapon_visuals()

func _spawn_flying_chappal() -> void:
	if chappal_scene:
		var ch = chappal_scene.instantiate()
		ch.player_ref = self
		ch.model_file = "res://models/weapons_3d/Chappal_3D.glb"
		get_tree().current_scene.add_child(ch)
		ch.global_transform = head.global_transform
		ch.global_position -= head.global_transform.basis.z * 1.1

func _spawn_flying_belan() -> void:
	if chappal_scene:
		var ch = chappal_scene.instantiate()
		ch.player_ref = self
		ch.model_file = "res://models/weapons_3d/Belan_3D.glb"
		get_tree().current_scene.add_child(ch)
		ch.global_transform = head.global_transform
		ch.global_position -= head.global_transform.basis.z * 1.1

func hit_by_car(force_vector: Vector3) -> void:
	if is_hit_by_car:
		return
	is_hit_by_car = true
	SoundManager.play_explode()
	add_trauma(0.85)
	take_damage(18)
	show_banner("HEAVY DRIVER! SMASHED BY THE OMNI VAN! Tap [KICK] to boot it!")
	impact_velocity = force_vector + Vector3(0.0, 8.0, 0.0)
	await get_tree().create_timer(0.85).timeout
	is_hit_by_car = false

func perform_quick_kick() -> void:
	can_kick = false
	if Global.vip_horn_unlocked:
		SoundManager.play_explode()
		show_banner("VIP PRESSURE HORN BLAST! SIDE PLEASE!")
	else:
		SoundManager.play_kick()
	gun_sprite.scale = Vector2(3.2, 3.2)
	gun_sprite.play("kick")
	add_trauma(0.38)
	await get_tree().create_timer(0.14).timeout
	var reach: float = 9.5 if Global.vip_horn_unlocked else 5.2
	var dmg: int = KICK_DAMAGE * (2 if Global.vip_horn_unlocked else 1)
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and global_position.distance_to(e.global_position) < reach:
			if e.has_method("take_damage"):
				e.take_damage(dmg)
			if "velocity" in e:
				var kick_dir2: Vector3 = -head.global_transform.basis.z
				e.velocity = (kick_dir2 + Vector3(0, 0.4, 0)).normalized() * KICK_PUSH_FORCE
	await get_tree().create_timer(0.30).timeout
	update_weapon_visuals()
	can_kick = true

func try_spend_ammo(amount: int) -> bool:
	if chai_fever_timer > 0.0:
		return true
	if current_ammo >= amount:
		current_ammo -= amount
		ammo_changed.emit(current_ammo)
		return true
	SoundManager.play_punch()
	show_banner("OUT OF AMMO! Use [5: CHAPPAL] or [2: FIST] or buy Ammo at [CHAI SHOP]!")
	return false

func fire_projectile(speed_mult: float, dmg: int) -> void:
	if projectile_scene:
		var bullet = projectile_scene.instantiate()
		get_tree().current_scene.add_child(bullet)
		bullet.global_transform = head.global_transform
		bullet.global_position -= head.global_transform.basis.z * 1.2
		bullet.damage = dmg
		bullet.speed *= speed_mult

func fire_melee(reach: float, dmg: int) -> void:
	if head_ray and head_ray.is_colliding():
		var dist: float = global_position.distance_to(head_ray.get_collision_point())
		if dist <= reach:
			var target = head_ray.get_collider()
			if target and target.has_method("take_damage"):
				target.take_damage(dmg)
				return
	var forward: Vector3 = -head.global_transform.basis.z
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and global_position.distance_to(e.global_position) <= reach:
			var dir_to: Vector3 = (e.global_position - global_position).normalized()
			if forward.dot(dir_to) > 0.45 and e.has_method("take_damage"):
				e.take_damage(dmg)
				return

func _try_grab() -> void:
	var candidate: Node3D = null
	if head_ray and head_ray.is_colliding():
		var t = head_ray.get_collider()
		if t and t.is_in_group("enemies") and global_position.distance_to(t.global_position) <= GRAB_DISTANCE:
			candidate = t
	if candidate == null:
		for e in get_tree().get_nodes_in_group("enemies"):
			if is_instance_valid(e) and e is CharacterBody3D and global_position.distance_to(e.global_position) <= GRAB_DISTANCE:
				candidate = e
				break
	if candidate:
		grabbed_enemy = candidate
		if "is_grabbed" in grabbed_enemy:
			grabbed_enemy.is_grabbed = true
		grabbed_enemy.reparent(head)
		grabbed_enemy.position = Vector3(0.0, -0.4, -2.5)
		show_banner("UTHA LE RE BABA! Tap [FIRE] again to YEET them into a wall!")
		update_weapon_visuals()
	else:
		show_banner("Move closer to an enemy to GRAB them!")

func _release_and_throw() -> void:
	if is_instance_valid(grabbed_enemy):
		var enemy_ref: Node3D = grabbed_enemy
		var forward_dir: Vector3 = -head.global_transform.basis.z
		gun_sprite.play("ghands_throw")
		enemy_ref.reparent(get_tree().current_scene)
		enemy_ref.global_position = head.global_position + (forward_dir * 1.8)
		if "is_grabbed" in enemy_ref:
			enemy_ref.is_grabbed = false
		if "velocity" in enemy_ref:
			enemy_ref.velocity = (forward_dir + Vector3(0, 0.18, 0)).normalized() * THROW_POWER
		grabbed_enemy = null
		show_banner("KHATAM! TATA! BYE BYE! ENEMY THROWN!")
		await get_tree().create_timer(0.28).timeout
		update_weapon_visuals()

func heal(amount: float) -> void:
	current_health = minf(current_health + amount, max_health)
	health_changed.emit(current_health)

func take_damage(amount: float) -> void:
	current_health -= amount
	health_changed.emit(current_health)
	SoundManager.play_player_hurt()
	if damage_flash:
		damage_flash.color.a = 0.42
	add_trauma(0.18)
	if current_health <= 0.0:
		die()

func die() -> void:
	player_died.emit()
	set_physics_process(false)
	Engine.time_scale = 1.0
	get_tree().change_scene_to_file("res://GameOver.tscn")

func _on_Player_player_died() -> void:
	pass

func add_ammo(amount: int) -> bool:
	if current_ammo >= max_ammo:
		return false
	current_ammo = mini(current_ammo + amount, max_ammo)
	ammo_changed.emit(current_ammo)
	return true

func perform_grenade_throw() -> void:
	if grenade_scene == null:
		return
	can_throw_grenade = false
	SoundManager.play_kick()
	if weapon_3d and weapon_3d.has_method("play_grenade_toss"):
		weapon_3d.play_grenade_toss()
	await get_tree().create_timer(0.22).timeout
	var grenade: RigidBody3D = grenade_scene.instantiate()
	get_tree().current_scene.add_child(grenade)
	var forward_dir: Vector3 = -head.global_transform.basis.z
	grenade.global_position = head.global_position + (forward_dir * 1.3)
	grenade.apply_central_impulse((forward_dir + Vector3(0.0, 0.4, 0.0)) * grenade_force)
	await get_tree().create_timer(0.35).timeout
	update_weapon_visuals()
	can_throw_grenade = true

func push(force_vector: Vector3) -> void:
	external_velocity += force_vector
