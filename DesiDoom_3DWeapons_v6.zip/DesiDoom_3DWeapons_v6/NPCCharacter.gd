extends Area3D

@export var npc_name: String = "Raju Chaiwala"
@export var dialogue: String = "GARAM CHAI PILO BHAI! 25 DIN MEIN HP DOUBLE!"
@export var role: String = "chaiwala"

var _vis: Node3D = null

func _ready() -> void:
	add_to_group("Interactable")
	_vis = load("res://scripts/EnemyVisual.gd").new()
	_vis.skin_path = ""
	if role == "dhol" or "Balli" in npc_name:
		_vis.model_path = "res://models/characters_3d/Punjabi_Gabru_3D.glb"
	else:
		_vis.model_path = "res://models/characters_3d/Raju_Chaiwala_3D.glb"
	_vis.model_scale = Vector3(1.05, 1.05, 1.05)
	add_child(_vis)

	var lbl := Label3D.new()
	lbl.text = npc_name + " (3D)
[Tap USE / CHAI SHOP]"
	lbl.font_size = 36
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(0.35, 1.0, 0.55)
	lbl.position = Vector3(0, 2.45, 0)
	add_child(lbl)

func interact(player: Node) -> void:
	SoundManager.play_pickup()
	if _vis:
		_vis.play(_vis.Anim.ATTACK)
	if player.has_method("show_banner"):
		player.show_banner(npc_name + ": "" + dialogue + """)
	if player.has_method("heal"):
		player.heal(15.0)
